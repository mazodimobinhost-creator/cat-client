/**
 * Cat Panel v6 worker test harness (Node 18+, no dependencies).
 * Usage: node scripts/panels/cat-panel.test.mjs
 * Covers: auth/session, master + per-user subscriptions (raw/b64/clash/singbox),
 * settings & users API, KV write budget, backup/restore, wire parsers, relay.
 */
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { readFileSync } from 'node:fs';
const here = path.dirname(fileURLToPath(import.meta.url));
// CAT_PANEL_WORKER=<path> runs the whole suite against an obfuscated artifact (release-parity proof).
const workerPath = process.env.CAT_PANEL_WORKER || path.join(here, '../../app/src/main/assets/panels/catclient.worker.js');
execFileSync(process.execPath, ['--check', workerPath], { stdio: 'pipe' });
console.log('✓ syntax check passed');
const mod = await import(workerPath);
// CI has real network → DoH inside subResponse would rewrite domain entries and
// break exact-sub assertions. Stub any DNS fetch; the seeded-cache domMap test
// below never fetches, so it stays hermetic.
const realFetch = globalThis.fetch;
globalThis.fetch = (input, init) => {
  const u = typeof input === 'string' ? input : (input && input.url) || String(input);
  if (String(u).includes('dns-query')) return Promise.reject(new Error('dns-stubbed-in-tests'));
  return realFetch(input, init);
};
const worker = mod.default; const T = mod._testing;
let failures = 0;
const failed = [];
// CI's failure report only keeps the tail of the log, so the names are repeated
// at the very end — otherwise a failure in the middle of this file is invisible.
function check(name, cond, extra) { if (cond) console.log('✓ ' + name); else { failures++; failed.push(name + (extra ? ' — ' + extra : '')); console.error('✗ ' + name + (extra ? ' — ' + extra : '')); } }
class FakeKV { constructor(){this.m=new Map();this.writes=0;this.reads=0;} async get(k){this.reads++;return this.m.has(k)?this.m.get(k):null;} async put(k,v){this.writes++;this.m.set(k,v);} async list(){return {keys:[...this.m.keys()].map(name=>({name}))};} async delete(k){this.m.delete(k);} }
const HOST = 'catpanel-demo.workers.dev';
const KV = new FakeKV();
const ENV = { CAT_KV: KV, UUID: '11111111-2222-4333-8444-555555555555' };
const MASTER = ENV.UUID;
function req(path, { method='GET', headers={}, body, env=ENV } = {}) {
  const init = { method, headers: Object.assign({}, headers) };
  if (body !== undefined) { init.body = typeof body === 'string' ? body : JSON.stringify(body); init.headers['content-type'] = 'application/json'; }
  return worker.fetch(new Request('https://' + HOST + path, init), env, { waitUntil(){} });
}
// health
{ const r = await req('/health'); const j = await r.json(); check('/health anonymous = bare ok (no fingerprint)', r.status===200 && j.ok===true && j.version===undefined && j.kv===undefined); }
// beta57 stealth default: / = camouflage landing, real UI at /panel
// 6.66.5 paste-and-go: «no password yet» is its own state. The root points at the
// setup screen (the card that shows the UUID and the one-tap login) instead of a
// dead-end login form. Camouflage still applies the moment a password exists —
// proven right here by setting one temporarily.
{ const r = await req('/'); check('first run (no password yet): / points at the setup screen', r.status===302 && r.headers.get('location')==='/panel'); }
{ const rp = await req('/panel'); const bp = await rp.text(); check('/panel shows the setup card (UUID + one-tap) before a password exists', rp.status===200 && bp.includes('/api/login') && bp.includes(MASTER)); }
{ const key = T.KV_KEYS.settings; const before = await T.readSettings(ENV);
  await KV.put(key, JSON.stringify(Object.assign({}, before, { passwordHash: await T.sha256Hex('temporary-check') }))); T.kvCacheClear();
  const r = await req('/'); const b = await r.text();
  check('/ serves camouflage once a password is set (locked)', r.status===200 && b.includes('Sora') && !b.includes('/api/login'));
  const rp = await req('/panel'); const bp = await rp.text();
  check('/panel is a plain login (no UUID) once a password is set', rp.status===200 && bp.includes('/api/login') && !bp.includes(MASTER));
  await KV.put(key, JSON.stringify(before)); T.kvCacheClear(); }
// api unauthorized
{ const r = await req('/api/settings'); check('/api/settings 401 without session', r.status===401); }
// login with uuid
let cookie='';
{ const r = await req('/api/login', { method:'POST', body:{ password: 'wrong' } }); check('login wrong → 401', r.status===401);
  const r2 = await req('/api/login', { method:'POST', body:{ password: MASTER } }); const j = await r2.json(); cookie = (r2.headers.get('set-cookie')||'').split(';')[0];
  check('login with UUID ok', r2.status===200 && j.ok && cookie.startsWith('cat_session=')); }
const auth = { cookie };
// beta68 regression (user report): manually added IPs (v4/v6/domain/pinned-port)
// MUST lead the sub in panel order — rotation shuffles only the defaults, and
// port-pinned scanner imports must appear at all (they never did).
{
  await req('/api/ips', { method:'POST', headers: auth, body:{ ips: ['104.16.1.1','2606:4700:d1::1','cf.example.com','104.17.1.2:2053#DE','[2606:4700::6810:84e5]:8443'], source:'manual' } });
  const sub = await (await req('/sub/' + MASTER)).text();
  // Compare positions in the ADDRESS order, not raw text offsets: the limit is
  // now shared between port waves, so any single default address may legitimately
  // fall outside the emitted window, and raw text also matches SNI values.
  const addrOrder = [...sub.matchAll(/@(\[[^\]]+\]|[^:@?]+):(\d{1,5})\?/g)].map((m) => m[1]);
  const iManual = addrOrder.indexOf('104.16.1.1');
  const iDefault = addrOrder.indexOf('speed.cloudflare.com');
  check('manual v4 leads the sub', iManual > -1 && (iDefault === -1 || iManual < iDefault), 'manual@' + iManual + ' default@' + iDefault);
  check('manual v6 bracketed in link', sub.includes('[2606:4700:d1::1]:443'));
  check('manual domain kept as address', sub.includes('cf.example.com]:443') || sub.includes('cf.example.com:443'));
  check('pinned v4 emitted on its verified port only', /104\.17\.1\.2:2053\?/.test(sub));
  check('pinned v6 emitted bracketed on 8443', sub.includes('[2606:4700::6810:84e5]:8443'));
  await req('/api/ips', { method:'POST', headers: auth, body:{ ips: [], replace: true } }); // restore baseline for later tests
}
// ================= beta71: monitor cron + cc-quality + domain-check + v6 pool =================
{
  // cronSelfCheck: no tg configured → must complete silently, KV ping written
  await T.cronSelfCheck(ENV);
  check('cronSelfCheck: KV ping stored', KV.m.has('cat_monitor_ping') && KV.m.has('cat_monitor_state_v1'));
  // cc-quality: anonymous → 401, owner → ok (no sockets in tests → empty cc map)
  const anon = await req('/api/cc-quality');
  check('cc-quality anonymous → 401', anon.status === 401);
  const own = await (await req('/api/cc-quality', { headers: auth })).json();
  check('cc-quality owner → ok shape', own.ok === true && typeof own.cc === 'object');
  // cronCountryQuality: without cloudflare:sockets it must not throw
  await T.cronCountryQuality(ENV);
  check('cronCountryQuality: no sockets → survives', true);
  // domain-check: stub DNS with a Cloudflare A answer
  const realFetch2 = globalThis.fetch;
  globalThis.fetch = async (input) => {
    const u = String(typeof input === 'string' ? input : input.url);
    if (u.includes('dns-query')) {
      return new Response(JSON.stringify({ Answer: [{ type: 1, data: '104.16.132.229' }] }), { status: 200 });
    }
    return realFetch2(input);
  };
  const anonDc = await req('/api/domain-check?host=example.com');
  check('domain-check anonymous → 401', anonDc.status === 401);
  const dc = await (await req('/api/domain-check?host=panel.example.com', { headers: auth })).json();
  globalThis.fetch = realFetch2;
  check('domain-check: CF domain detected', dc.ok === true && dc.onCloudflare === true && dc.ips[0] === '104.16.132.229');
  check('built-in v6 pool exported (11 anycast)', Array.isArray(T.CF_V6_POOL) && T.CF_V6_POOL.length === 11);
}
{ const r = await req('/panel', { headers: auth }); const b = await r.text(); check('/panel shows panel with cookie', b.includes('v-dash') && b.includes('CAT_PANEL') === false && b.includes('Cat Panel')); }
{ const r = await req('/api/settings', { headers: auth }); const j = await r.json(); check('settings GET', j.ok && j.uuid===MASTER && j.kv===true && j.passwordSource==='uuid' && j.links.sub.endsWith('/sub/'+MASTER)); }
// subscription master
{ const r = await req('/sub/' + MASTER + '?rotate=off'); const b = await r.text();
  check('/sub/<uuid> 200', r.status===200);
  const lines = b.trim().split('\n');
  check('has vless + trojan', b.includes('vless://') && b.includes('trojan://'));
  const firstName = decodeURIComponent(b.split('\n')[0].split('#')[1] || '');
  check('BPB-style remark', firstName.includes('VLESS - Clean IP') || firstName.includes('VLESS - WorkerOnly'), firstName);
  check('first entry is TLS 443', /:443\?/.test(lines[0]), lines[0]);
  // :80 sits after the BPB 443→8080 waves (beyond the 48-entry default limit);
  // the default plain-port set still contains it.
  check('plain ports default include :80', T.normalizeSettings({}).plainPorts.map(Number).includes(80));
  check('has BPB-signature :8080 plain entries (443 → 8080 order)', /:8080\?encryption=none&security=none/.test(b));
  const l8080 = b.split('\n').find((l) => /:8080\?/.test(l));
  check(':8080 remark is BPB-style «Clean IP : 8080»', decodeURIComponent(l8080.split('#')[1]).includes('Clean IP : 8080'), decodeURIComponent(l8080.split('#')[1]));
  check('host header + BPB path', b.includes('host=' + HOST) && b.includes(encodeURIComponent('?ed=2560')) && b.includes(encodeURIComponent('/vl/')));
  check('userinfo header', (r.headers.get('subscription-userinfo')||'').includes('total=0'));
  const isSpoof = (l) => /%F0%9F%8E%AF|%F0%9F%A7%AC/.test(l); // 🎯 PX / 🧬 SNI sections
  const cleanLines = lines.filter((l) => !isSpoof(l));
  check('entry limit respected (clean section)', cleanLines.length <= 48 && cleanLines.length >= 20, String(lines.length) + ' total, clean=' + cleanLines.length);
  check('spoof section present in plain sub (PX or SNI)', lines.some((l) => isSpoof(l)));
  const r64 = await req('/sub64/' + MASTER + '?rotate=off'); const b64 = await r64.text(); check('/sub64 is base64 of /sub', T.b64decode(b64) === (await (await req('/sub/' + MASTER + '?rotate=off')).text()));
  const rb = await req('/sub/' + MASTER + '?b64=1'); check('?b64=1 works', T.b64decode(await rb.text()).includes('vless://'));
  const bad = await req('/sub/00000000-0000-4000-8000-000000000000'); check('unknown uuid 404', bad.status===404);
  { // beta43: BPB-parity — ONE link serves every client (UA + ?target=)
    const rc = await req('/sub/' + MASTER + '?rotate=off', { headers:{ 'user-agent':'ClashMetaForAndroid/2.11.5' } });
    check('UA clash → yaml', (rc.headers.get('content-type')||'').includes('yaml'));
    const rs = await req('/sub/' + MASTER + '?rotate=off', { headers:{ 'user-agent':'SFI/1.12.0 (sing-box; ios)' } });
    check('UA sing-box → json', (rs.headers.get('content-type')||'').includes('json') && (await rs.text()).includes('"outbounds"'));
    const rt = await req('/clash/' + MASTER + '?target=base64&rotate=off');
    check('?target=base64 overrides path kind', T.b64decode(await rt.text()).includes('vless://'));
    const rp2 = await req('/sub/' + MASTER + '?rotate=off');
    check('profile-web-page-url header', !!(rp2.headers.get('profile-web-page-url')||'').includes('/info/'));
    check('safeEqualHex', T.safeEqualHex('abcd','abcd')===true && T.safeEqualHex('abcd','abce')===false && T.safeEqualHex('abc','abcd')===false);
  }
  const noKey = await req('/sub'); check('/sub without uuid 404 when OPEN_SUB unset', noKey.status===404);
  const open = await req('/sub', { env: Object.assign({}, ENV, { OPEN_SUB: 'true' }) }); check('/sub with OPEN_SUB serves master', open.status===200 && (await open.text()).includes('vless://'));
}
{ const r = await req('/clash/' + MASTER); const y = await r.text(); check('clash yaml', r.status===200 && y.includes('proxies:') && y.includes('type: vless') && y.includes('type: trojan') && y.includes('MATCH,🐱 Cat') && !y.includes('tls: false\n    password')); }
{ const r = await req('/singbox/' + MASTER); const j = await r.json(); check('singbox json', j.outbounds.some(o=>o.type==='vless') && j.outbounds[0].type==='selector' && j.route.final==='🐱 Cat'); }
// settings PUT
{ const r = await req('/api/settings', { method:'PUT', headers: auth, body:{ ips:['1.2.3.4','www.example.com','bad ip'], tlsPorts:[443,2053], plainEnabled:false, protocols:{vless:true,trojan:false}, entryLimit:10, subRotate:'off' } }); const j = await r.json();
  check('settings PUT', j.ok && j.persisted && j.settings.ips.length===3 && j.settings.tlsPorts.join()==='443,2053' && j.settings.protocols.trojan===false);
  const s = await req('/sub/' + MASTER); const b = await s.text(); const lines=b.trim().split('\n');
  check('owner ips first', lines[0].includes('@1.2.3.4:443') && lines[1].includes('@www.example.com:443'), lines[0]);
  const clean = lines.filter((l) => !/%F0%9F%8E%AF|%F0%9F%A7%AC/.test(l));
  check('trojan disabled + no plain + limit', !b.includes('trojan://') && !b.includes('security=none') && clean.length===10, 'clean=' + clean.length);
}
// password change
{ const writes = KV.writes; const r = await req('/api/settings', { method:'PUT', headers: auth, body:{ password:'s3cret' } }); const j = await r.json(); const newCookie=(r.headers.get('set-cookie')||'').split(';')[0];
  check('password set → new cookie', j.ok && j.settings.hasPassword && newCookie && newCookie!==cookie);
  const old = await req('/api/settings', { headers: auth }); check('old session invalid after password change', old.status===401);
  const bearer = await req('/api/settings', { headers:{ authorization:'Bearer s3cret' } }); check('bearer password works', bearer.status===200);
  const uuidLogin = await req('/api/login', { method:'POST', body:{ password: MASTER } }); check('uuid no longer a password', uuidLogin.status===401);
  auth.cookie = newCookie; check('settings save persists settings + events ring (tolerating throttled last-seen writes)', KV.writes >= writes + 2, String(KV.writes - writes)); }
// beta92: an empty address list must not produce a blank master/user sub. The
// fallback to built-in addresses + worker hostname is render-only and never
// rewrites the owner's disabled defaults / host switches.
{
  const fallbackMod = await import(workerPath + '?empty-sub-fallback=1');
  const fallbackWorker = fallbackMod.default;
  const FT = fallbackMod._testing;
  const fallbackKv = new FakeKV();
  const fallbackEnv = { CAT_KV: fallbackKv, UUID: MASTER, OPEN_PANEL: 'true' };
  FT.kvCacheClear();
  await FT.writeSettings(fallbackEnv, {
    ips: [], useDefaults: false, includeHost: false,
    protocols: { vless: true, trojan: true },
    tlsPorts: [443], plainEnabled: false, plainPorts: [],
  });
  const fallbackResponse = await fallbackWorker.fetch(
    new Request('https://' + HOST + '/sub/' + MASTER), fallbackEnv, { waitUntil() {} },
  );
  const fallbackSub = await fallbackResponse.text();
  check('empty address list falls back to built-in configs + worker host',
    fallbackResponse.status === 200 && fallbackSub.includes('vless://') && fallbackSub.includes('trojan://') &&
      fallbackSub.includes('104.16.132.229') && fallbackSub.includes(HOST),
    fallbackSub.slice(0, 180));
  const unchanged = await FT.readSettings(fallbackEnv);
  check('empty-list fallback is not persisted', unchanged.useDefaults === false &&
    unchanged.includeHost === false && unchanged.ips.length === 0);

  // Screenshot-equivalent values are valid input; a production failure should
  // therefore be diagnosed from its API response, not blamed on this username or expiry.
  const formResponse = await fallbackWorker.fetch(new Request('https://' + HOST + '/api/users', {
    method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ name: 'cat-rdwma2', protocols: { vless: true, trojan: true }, days: 365, enabled: true }),
  }), fallbackEnv, { waitUntil() {} });
  const formResult = await formResponse.json();
  const expectedExpiry = Date.now() + 365 * 86400000;
  check('screenshot new-user values are accepted (201, active, VLESS+Trojan, 365 days)',
    formResponse.status === 201 && formResult.ok && formResult.user.name === 'cat-rdwma2' &&
      formResult.user.enabled === true && formResult.user.protocols.vless === true &&
      formResult.user.protocols.trojan === true && Math.abs(formResult.user.expiresAt - expectedExpiry) < 5000,
    JSON.stringify(formResult));
}

// users
let user;
{ const r = await req('/api/users', { method:'POST', headers: auth, body:{ name:'ali', days:30 } }); const j = await r.json(); user = j.user;
  check('create user', r.status===201 && j.ok && T.isUuid(user.id) && user.expiresAt > Date.now() && user.links.sub.endsWith('/u/'+user.id));
  const l = await req('/api/users', { headers: auth }); check('list users', (await l.json()).users.length===1);
  const s = await req('/u/' + user.id); const b = await s.text(); check('user sub works + uses user uuid', s.status===200 && b.includes('vless://'+user.id+'@'));
  check('user sub has expire', (s.headers.get('subscription-userinfo')||'').includes('expire='));
  const c = await req('/u/' + user.id + '/clash'); check('user clash', (await c.text()).includes('uuid: '+user.id));
  const sb = await req('/u/' + user.id + '/singbox'); check('user singbox', (await sb.json()).outbounds.some(o=>o.uuid===user.id));
  const info = await req('/info/' + user.id); check('user info page', info.status===200 && (await info.text()).includes('ali'));
  const tog = await req('/api/users/'+user.id+'/toggle', { method:'POST', headers: auth, body:{} }); check('toggle → disabled', (await tog.json()).user.enabled===false);
  const blocked = await req('/u/' + user.id); check('disabled user sub 403', blocked.status===403);
  await req('/api/users/'+user.id+'/toggle', { method:'POST', headers: auth, body:{} });
  const exp = await req('/api/users/'+user.id, { method:'PUT', headers: auth, body:{ expiresAt: Date.now()-1000 } }); check('set expired', (await exp.json()).user.status==='expired');
  const blocked2 = await req('/u/' + user.id); check('expired user sub 403', blocked2.status===403);
  const renew = await req('/api/users/'+user.id+'/renew', { method:'POST', headers: auth, body:{ days: 10 } }); const rj = await renew.json(); check('renew from now', rj.user.expiresAt > Date.now() + 9*86400000);
  const tun = await T.tunnelAuth(ENV, user.id, MASTER); check('tunnelAuth user ok', tun.ok);
  const tunM = await T.tunnelAuth(ENV, MASTER, MASTER); check('tunnelAuth master ok', tun.ok && tunM.master);
  const tunX = await T.tunnelAuth(ENV, '00000000-0000-4000-8000-000000000000', MASTER); check('tunnelAuth unknown rejected', !tunX.ok);
}
// ips import
{ const r = await req('/api/ips', { method:'POST', headers: auth, body:{ ips:'5.6.7.8\n9.9.9.9, cdn.example.org junk' } }); const j = await r.json(); check('ips import appends', j.ok && j.ips.includes('5.6.7.8') && j.ips.includes('1.2.3.4') && !j.ips.includes('junk')); }
{ // beta39: replace mode (app «🧹 جایگزینی») + ProxyIP ip:port never normalized away
  const r = await req('/api/ips', { method:'POST', headers: auth, body:{ ips:['198.51.100.7:2053#CA','203.0.113.9'], replace:true } }); const j = await r.json();
  check('ips REPLACE wipes old list (exact set)', j.ok && j.ips.length===2 && j.ips.includes('198.51.100.7:2053') && j.ips.includes('203.0.113.9'), JSON.stringify(j.ips));
  const st = (await (await req('/api/settings', { headers: auth })).json()).settings;
  check('replaced entry kept its pin+tag', st.ipCountries['198.51.100.7:2053']==='CA', JSON.stringify(st.ipCountries));
  await req('/api/settings', { method:'PUT', headers: auth, body:{ proxyIps:['104.17.1.1:2053','83.147.217.103:1080','ip.sb'] } });
  const st2 = (await (await req('/api/settings', { headers: auth })).json()).settings;
  // beta94: an explicit pin is still never stripped (2053 / 1080 stay). Only a
  // PORTLESS relay changes: it now carries the default port so the UI can show
  // what will be dialed — «ip.sb» is stored as «ip.sb:443».
  check('proxyIps keep ip:port exactly (never stripped)', JSON.stringify(st2.proxyIps)===JSON.stringify(['104.17.1.1:2053','83.147.217.103:1080','ip.sb:443']), JSON.stringify(st2.proxyIps));
}
// backup
{ const r = await req('/api/backup', { headers: auth }); const j = await r.json(); check('backup export', j.settings && j.users.length===1);
  const KV2 = new FakeKV(); const env2 = { CAT_KV: KV2, UUID: MASTER }; T.kvCacheClear();
  const login = await req('/api/login', { method:'POST', body:{ password: MASTER }, env: env2 }); const c2=(login.headers.get('set-cookie')||'').split(';')[0];
  // 6.67: the export MASKS secrets by default and a restore deliberately skips
  // masked fields — a backup must never be able to wipe a live secret. Raw
  // values are opt-in (?includeSecrets=1) for a full clone.
  check('backup masks the password hash by default', j.settings.passwordHash === '***MASKED-BY-CAT-PANEL***', String(j.settings.passwordHash).slice(0, 40));
  const rs = await req('/api/backup', { method:'POST', headers:{cookie:c2}, body: j, env: env2 }); check('backup restore', (await rs.json()).ok);
  const lu = await req('/api/users', { headers:{ cookie:c2 }, env: env2 }); check('restored users', lu.status===200 && (await lu.json()).users[0].name==='ali');
  const wrong = await req('/api/users', { headers:{ authorization:'Bearer s3cret' }, env: env2 });
  check('a masked backup never restores the old password', wrong.status===401);
  // …back to the first panel: the read cache is per key NAME, not per env, so it
  // has to be dropped before switching sides (a test-only artefact).
  T.kvCacheClear();
  const raw = await (await req('/api/backup?includeSecrets=1', { headers: auth })).json();
  check('?includeSecrets=1 ships the real hash', /^[0-9a-f]{64}$/.test(String(raw.settings.passwordHash || '')), String(raw.settings.passwordHash).slice(0, 24));
  const KV3 = new FakeKV(); const env3 = { CAT_KV: KV3, UUID: MASTER }; T.kvCacheClear();
  const rs3 = await req('/api/backup', { method:'POST', headers:{ authorization:'Bearer ' + MASTER }, body: raw, env: env3 }); check('raw restore accepted', (await rs3.json()).ok);
  const lu3 = await req('/api/users', { headers:{ authorization:'Bearer s3cret' }, env: env3 });
  check('a raw backup restores users + password', lu3.status===200 && (await lu3.json()).users[0].name==='ali');
  T.kvCacheClear(); }
// open panel
{ const KV3 = new FakeKV(); const env3 = { CAT_KV: KV3, UUID: MASTER, OPEN_PANEL:'true' }; const r = await req('/panel', { env: env3 }); check('OPEN_PANEL serves panel without login', (await r.text()).includes('v-dash'));
  const r2 = await req('/api/settings', { env: env3 }); check('OPEN_PANEL api open', r2.status===200 && (await r2.json()).open===true); T.kvCacheClear(); }
// no KV
{ const envNo = { UUID: MASTER }; const r = await req('/sub/' + MASTER, { env: envNo }); check('works without KV', r.status===200); const ho = await req('/health', { env: envNo, headers: { cookie } }); check('health (owner) reports kv:false', (await ho.json()).kv===false); }
// derived uuid
{ const u = await T.resolveUuid(HOST, {}); check('derived uuid stable + valid', T.isUuid(u) && u === await T.resolveUuid(HOST, {})); }
// qr
{ const r = await req('/qr.svg?text=hello'); check('qr svg', r.status===200 && (await r.text()).startsWith('<svg')); }
// geo endpoint shape (no network in test → ok:false but 200)
{ const r = await req('/api/geo?ip=1.1.1.1'); check('geo returns json', r.status===200 && typeof (await r.json()).ok==='boolean'); }
// scan targets
{ const r = await req('/api/scan-targets.json'); const j = await r.json(); check('scan targets', j.ranges.length>10 && j.sni==='skk.moe'); }
// wire parsers
{ const uuidHex = MASTER.replace(/-/g,''); const bytes = new Uint8Array([0, ...uuidHex.match(/../g).map(h=>parseInt(h,16)), 0, 1, 0x01,0xbb, 2, 11, ...new TextEncoder().encode('example.com'), 0x47,0x45,0x54]);
  const v = T.parseVlessHeader(bytes); check('vless header parse', v && v.uuid===MASTER && v.host==='example.com' && v.port===443 && v.command===1 && v.rest.length===3);
  check('sha224 vector', T.sha224Hex('abc')==='23097d223405d8228642a477bda255b32aadbce4bda0b3f7e36c9da7');
  check('cf ip detection', T.isCloudflareIp('104.16.1.1') && !T.isCloudflareIp('8.8.8.8') && T.isCloudflareIp('2606:4700::1'));
  check('tunnel paths (legacy + BPB)', T.isTunnelPath('/ws', {}) && T.isTunnelPath('/trojan', {}) && T.isTunnelPath('/vl/abcdef0123456789', {}) && T.isTunnelPath('/tr/abcdef0123456789', {}) && !T.isTunnelPath('/sub', {}));
}
// tunnel e2e with fake sockets
{
  const sent = []; let closed = false;
  const fakeSockets = { connect(opts) { const chunks=[]; let resolveRead; const readable = new ReadableStream({ start(c){ c.enqueue(new TextEncoder().encode('HTTP/1.1 200 OK\r\n\r\nhi')); c.close(); } });
    const writable = new WritableStream({ write(chunk){ sent.push(new TextDecoder().decode(chunk)); } }); return { opened: Promise.resolve(), readable, writable, close(){ closed = true; } }; } };
  T.__setSockets(fakeSockets);
  const out = []; const ws = { readyState: 1, listeners: {}, addEventListener(n,f){ (this.listeners[n]=this.listeners[n]||[]).push(f); }, send(d){ out.push(new Uint8Array(d)); }, close(){ this.readyState = 3; } };
  const uuidHex = MASTER.replace(/-/g,''); const header = new Uint8Array([0, ...uuidHex.match(/../g).map(h=>parseInt(h,16)), 0, 1, 0x00,0x50, 1, 93,184,216,34, ...new TextEncoder().encode('GET / HTTP/1.1\r\n\r\n')]);
  const job = T.handleTunnelConnection(ws, ENV, { earlyDataHeader: Buffer.from(header).toString('base64url'), masterUuid: MASTER });
  await new Promise(r=>setTimeout(r,50)); (ws.listeners.close||[]).forEach(f=>f({}));
  await job;
  check('tunnel: upstream got request', sent.join('').includes('GET / HTTP/1.1'));
  check('tunnel: downstream got vless response header + body', out.length>=1 && out[0][0]===0 && out[0][1]===0 && new TextDecoder().decode(out[0].subarray(2)).startsWith('HTTP/1.1 200'));
  check('tunnel: socket closed', closed);
}

// sub query overrides: pin one address / port / proto
{ const r = await req('/sub/' + MASTER + '?addr=1.2.3.4&port=443&proto=vless&limit=1'); const b = (await r.text()).trim().split('\n');
  check('?addr&port&proto&limit=1 → exactly one pinned vless config', b.length===1 && b[0].startsWith('vless://'+MASTER+'@1.2.3.4:443?'), b[0]);
  const c = await req('/clash/' + MASTER + '?addr=www.example.com&limit=2'); const y = await c.text();
  check('clash honours ?addr', y.includes('server: "www.example.com"') && !y.includes('1.2.3.4'));
  check('clash select group defaults to concrete proxy, Auto is fallback type', y.indexOf('type: select') < y.indexOf('⚡ Auto') && y.includes('type: fallback'));
  const sb = await (await req('/singbox/' + MASTER)).json(); const sel = sb.outbounds.find(o=>o.type==='selector');
  check('singbox selector default = first concrete outbound (stable exit)', sel.default !== '⚡ Auto' && sel.outbounds[0] === sel.default); }
// chain parsing + settings
{ const c = T.parseChain('socks5://user:p%40ss@1.2.3.4:1080'); check('parseChain socks5 w/ auth', c && c.type==='socks5' && c.user==='user' && c.pass==='p@ss' && c.host==='1.2.3.4' && c.port===1080);
  const h = T.parseChain('http://[2001:db8::1]:3128'); check('parseChain http v6', h && h.type==='http' && h.host==='2001:db8::1' && h.port===3128);
  check('parseChain rejects junk', !T.parseChain('vless://x') && !T.parseChain('socks5://host') && !T.parseChain('socks5://host:99999'));
  const r = await req('/api/settings', { method:'PUT', headers: auth, body:{ chain:'socks5://relay.example.net:1080', chainMode:'all' } }); const j = await r.json();
  check('settings accept chain', j.ok && j.settings.chain==='socks5://relay.example.net:1080' && j.settings.chainMode==='all');
  const g = await (await req('/api/settings', { headers: auth })).json(); check('settings GET exposes chain summary', g.chain && g.chain.type==='socks5' && g.chain.host==='relay.example.net');
  const bad = await (await req('/api/settings', { method:'PUT', headers: auth, body:{ chain:'garbage' } })).json(); check('invalid chain is dropped', bad.settings.chain==='');
  await req('/api/settings', { method:'PUT', headers: auth, body:{ chain:'' } }); }
// chain dial: fake SOCKS5 relay — every connection must go through it
{
  const dials = []; const relayWrites = [];
  function fakeRelaySocket() {
    let ctrl; const readable = new ReadableStream({ start(c){ ctrl = c; } });
    let stage = 0;
    const writable = new WritableStream({ write(chunk){ relayWrites.push(Array.from(chunk));
      if (stage===0) { ctrl.enqueue(new Uint8Array([5,0])); stage=1; return; }
      if (stage===1) { // CONNECT request: 5,1,0,atyp...
        const atyp = chunk[3]; const dom = atyp===3 ? new TextDecoder().decode(chunk.subarray(5,5+chunk[4])) : '';
        dials.push(dom); ctrl.enqueue(new Uint8Array([5,0,0,1, 9,9,9,9, 0,80])); stage=2; return; }
      // payload → echo back an HTTP answer
      ctrl.enqueue(new TextEncoder().encode('HTTP/1.1 200 OK\r\n\r\nvia-chain')); ctrl.close(); } });
    return { opened: Promise.resolve(), readable, writable, close(){} };
  }
  const connects = [];
  T.__setSockets({ connect(opts){ connects.push(opts.hostname+':'+opts.port); return fakeRelaySocket(); } });
  const envChain = { UUID: MASTER }; T.kvCacheClear();
  const settings = T.normalizeSettings({ chain: 'socks5://relay.example.net:1080', chainMode: 'all' });
  const out = []; const ws = { readyState: 1, listeners: {}, addEventListener(n,f){ (this.listeners[n]=this.listeners[n]||[]).push(f); }, send(d){ out.push(new Uint8Array(d)); }, close(){ this.readyState = 3; } };
  const uuidHex = MASTER.replace(/-/g,''); const header = new Uint8Array([0, ...uuidHex.match(/../g).map(h=>parseInt(h,16)), 0, 1, 0x01,0xbb, 2, 10, ...new TextEncoder().encode('google.com'), ...new TextEncoder().encode('GET / HTTP/1.1\r\n\r\n')]);
  const job = T.handleTunnelConnection(ws, envChain, { earlyDataHeader: Buffer.from(header).toString('base64url'), masterUuid: MASTER, settings });
  await new Promise(r=>setTimeout(r,80)); (ws.listeners.close||[]).forEach(f=>f({})); await job;
  check('chain: TCP went to the relay, not the destination', connects.length===1 && connects[0]==='relay.example.net:1080', connects.join());
  check('chain: SOCKS5 CONNECT carried the real destination', dials[0]==='google.com', dials.join());
  check('chain: payload relayed + reply delivered with vless header', out.length>=1 && out[0][0]===0 && new TextDecoder().decode(out[0].subarray(2)).includes('via-chain'));
  // http CONNECT variant
  const httpWrites = []; let hctrl;
  T.__setSockets({ connect(){ return { opened: Promise.resolve(), readable: new ReadableStream({ start(c){ hctrl=c; } }), writable: new WritableStream({ write(chunk){ const t=new TextDecoder().decode(chunk); httpWrites.push(t); if (t.startsWith('CONNECT')) hctrl.enqueue(new TextEncoder().encode('HTTP/1.1 200 Connection established\r\n\r\n')); else { hctrl.enqueue(new TextEncoder().encode('ok-http')); hctrl.close(); } } }), close(){} }; } });
  const d = await T.dialTarget('example.org', 443, envChain, T.normalizeSettings({ chain: 'http://u:p@proxy.example.net:3128' }), null);
  check('http CONNECT: request + basic auth sent', httpWrites[0].startsWith('CONNECT example.org:443 HTTP/1.1') && httpWrites[0].includes('Proxy-Authorization: Basic ' + Buffer.from('u:p').toString('base64')));
  check('http CONNECT: returns socket via chain', d.via==='chain');
  // chainMode=cf: non-CF destination goes direct
  const direct = []; T.__setSockets({ connect(opts){ direct.push(opts.hostname); return { opened: Promise.resolve(), readable: new ReadableStream({ start(c){ c.close(); } }), writable: new WritableStream(), close(){} }; } });
  const d2 = await T.dialTarget('example.org', 443, envChain, T.normalizeSettings({ chain: 'socks5://relay.example.net:1080', chainMode: 'cf' }), null);
  check('chainMode=cf: non-Cloudflare target dialled directly', d2.via==='direct' && direct[0]==='example.org');
  // strict chain: failure must not fall back
  T.__setSockets({ connect(){ throw new Error('relay down'); } });
  let threw = false; try { await T.dialTarget('example.org', 443, envChain, T.normalizeSettings({ chain: 'socks5://relay.example.net:1080', chainStrict: true }), null); } catch (e) { threw = true; }
  check('chainStrict: no fallback when relay is down', threw);
}

// countries: tags, preferred country first, strict filter, Clash fallback group, sing-box default
{
  T.kvCacheClear();
  const r = await (await req('/api/ips', { method:'POST', headers: auth, body:{ ips:['5.5.5.5#DE','6.6.6.6|TR','7.7.7.7'], replace:true } })).json();
  check('ips accept country tags, addresses stay clean', r.ips.join()==='5.5.5.5,6.6.6.6,7.7.7.7');
  const cs = await (await req('/api/countries', { headers: auth })).json();
  check('country summary groups addresses', cs.countries.map(c=>c.code).join()==='DE,TR' && cs.untagged.includes('7.7.7.7') && cs.countries[0].flag==='🇩🇪');
  const set = await (await req('/api/countries', { method:'PUT', headers: auth, body:{ country:'tr', countryFallback:'auto', ipCountries:{ '7.7.7.7':'nl' } } })).json();
  check('preferred country saved + manual tag', set.preferred==='TR' && set.countries.map(c=>c.code).join()==='DE,NL,TR');
  const sub = (await (await req('/sub/' + MASTER + '?limit=12&rotate=off')).text()).trim().split('\n');
  check('preferred country entries come first with flag names', sub[0].includes('@6.6.6.6:') && decodeURIComponent(sub[0].split('#')[1]).startsWith('🇹🇷'));
  check('other countries follow as fallback', sub.some(l=>l.includes('@5.5.5.5:')));
  const de = (await (await req('/sub/' + MASTER + '?country=DE&strict=1')).text()).trim().split('\n');
  check('?country=DE&strict=1 → only Germany', de.length>0 && de.every(l=>l.includes('@5.5.5.5:')));
  const y = await (await req('/clash/' + MASTER + '?rotate=off')).text();
  check('clash root = fallback [preferred country, Auto]', /name: "🐱 Cat"\n    type: fallback\n[\s\S]*?- "🇹🇷 Turkey"\n      - "⚡ Auto"/.test(y));
  check('clash has url-test group per country', y.includes('- name: "🇩🇪 Germany"\n    type: url-test') && y.includes('- name: "🇳🇱 Netherlands"'));
  const sb = await (await req('/singbox/' + MASTER + '?rotate=off')).json(); const sel = sb.outbounds.find(o=>o.tag==='🐱 Cat');
  check('singbox selector defaults to preferred country urltest', sel.default==='🇹🇷 Turkey' && sb.outbounds.some(o=>o.type==='urltest' && o.tag==='🇹🇷 Turkey'));
  await req('/api/countries', { method:'PUT', headers: auth, body:{ countryFallback:'none' } });
  const only = (await (await req('/sub/' + MASTER + '?limit=20')).text()).trim().split('\n');
  check('countryFallback=none → sub contains only preferred country', only.every(l=>l.includes('@6.6.6.6:')));
  const y2 = await (await req('/clash/' + MASTER)).text();
  check('countryFallback=none → clash root is select (no auto-leave)', /name: "🐱 Cat"\n    type: select/.test(y2));
  // proxy ip order honours preferred country
  // beta94: both relays are pinned to the default port and the country tag follows.
  const st = T.normalizeSettings({ country:'TR', proxyIps:['a.example','b.example'], proxyCountries:{ 'b.example':'TR' } });
  check('proxyIpList puts preferred-country proxy first', T.proxyIpList({}, st)[0]==='b.example:443' && st.proxyCountries['b.example:443']==='TR', JSON.stringify(T.proxyIpList({}, st)));
  const colo = await req('/api/colo'); check('/api/colo is public JSON', colo.status===200 && (await colo.json()).ok===true);
  check('helpers', T.splitAddrTag('1.2.3.4#de').cc==='DE' && T.normalizeCountry('xx')==='' && T.countryLabel('')==='🌐 Other');
  await req('/api/countries', { method:'PUT', headers: auth, body:{ country:'', countryFallback:'auto' } });
  await req('/api/ips', { method:'POST', headers: auth, body:{ ips:[], replace:true } });
}

// routing toggles, fragment/TLS extras, full-Xray subscription
{
  T.kvCacheClear();
  const y0 = await (await req('/clash/' + MASTER)).text();
  check('defaults: bypass Iran on, ads off', y0.includes('GEOIP,IR,DIRECT') && y0.includes('GEOSITE,category-ir,DIRECT') && !y0.includes('category-ads-all'));
  const sb0 = await (await req('/singbox/' + MASTER)).json(); check('fragment is opt-in (off by default)', !sb0.outbounds.some(o=>o.tls_fragment));
  const x0 = (await (await req('/xray/' + MASTER + '?raw=1&limit=1')).json())[0]; check('xray: no fragment outbound by default', !x0.outbounds.some(o=>o.tag==='fragment') && !x0.outbounds[0].streamSettings.sockopt.dialerProxy);
  const sv = await (await req('/api/settings', { method:'PUT', headers: auth, body:{ blockAds:true, bypassIran:false, fragment:{ enabled:true, packets:'1-3', length:'5-50', interval:'1-2' }, alpn:'h2', cipherSuites:'TLS_AES_128_GCM_SHA256:bad chars!' } })).json();
  check('settings normalise fragment/alpn/ciphers', sv.settings.fragment.packets==='1-3' && sv.settings.fragment.length==='5-50' && sv.settings.alpn==='h2' && sv.settings.cipherSuites==='TLS_AES_128_GCM_SHA256:badchars');
  const y1 = await (await req('/clash/' + MASTER)).text();
  check('clash: ads REJECT rule, no Iran rules when off', y1.includes('GEOSITE,category-ads-all,REJECT') && !y1.includes('GEOIP,IR,DIRECT'));
  const sb = await (await req('/singbox/' + MASTER)).json();
  check('singbox: ads rule_set + reject, tls_fragment, alpn', sb.route.rule_set.some(r=>r.tag==='geosite-ads') && sb.route.rules.some(r=>r.action==='reject') && sb.outbounds.some(o=>o.tls && o.tls_fragment===true && o.tls.alpn[0]==='h2'));
  const xr = await req('/xray/' + MASTER + '?raw=1&limit=2'); const cfgs = await xr.json();
  check('xray: full JSON configs list', Array.isArray(cfgs) && cfgs.length===2 && cfgs[0].outbounds[0].protocol==='vless' && cfgs[0].remarks);
  const o = cfgs[0].outbounds; const frag = o.find(x=>x.tag==='fragment');
  check('xray: fragment outbound + dialerProxy', frag && frag.settings.fragment.packets==='1-3' && o[0].streamSettings.sockopt.dialerProxy==='fragment');
  check('xray: tls extras + ws host', o[0].streamSettings.tlsSettings.cipherSuites.startsWith('TLS_AES') && o[0].streamSettings.wsSettings.headers.Host && o[0].streamSettings.tlsSettings.alpn[0]==='h2');
  check('xray: ads blocked, iran not bypassed', cfgs[0].routing.rules.some(r=>r.outboundTag==='block') && !cfgs[0].routing.rules.some(r=>(r.ip||[]).includes('geoip:ir')));
  const b64 = await (await req('/xray/' + MASTER + '?limit=1')).text();
  check('xray default body is base64 (v2rayNG import)', JSON.parse(Buffer.from(b64,'base64').toString()).length===1);
  const ux = await req('/u/' + MASTER + '/xray?raw=1&limit=1'); check('/u/<token>/xray works', ux.status===200);
  await req('/api/settings', { method:'PUT', headers: auth, body:{ blockAds:false, bypassIran:true, fragment:{ enabled:true }, alpn:'http/1.1', cipherSuites:'' } });
  const xr2 = (await (await req('/xray/' + MASTER + '?raw=1&limit=1')).json())[0];
  check('xray: iran bypass rules when on', xr2.routing.rules.some(r=>(r.ip||[]).includes('geoip:ir')) && xr2.routing.rules.some(r=>(r.domain||[]).includes('geosite:category-ir')));
  const links = (await (await req('/api/settings', { headers: auth })).json()).links; check('links expose xray', /\/xray\//.test(links.xray));
}

// telegram bot: webhook secret + admin gate + commands (fetch to Telegram is stubbed)
{
  T.kvCacheClear();
  const token = '123456789:AAHfakeTokenForTestsOnly_abcdefghijk';
  const sv = await (await req('/api/settings', { method:'PUT', headers: auth, body:{ tgToken: token, tgAdmins: ['42', 'junk'] } })).json();
  check('tg settings normalised, token masked in response', sv.settings.tgAdmins.join()==='42' && sv.settings.tgToken.startsWith('••••'));
  const masked = await (await req('/api/settings', { method:'PUT', headers: auth, body:{ tgToken: '••••hijk' } })).json();
  check('masked token echo does not wipe the real token', masked.settings.tgToken.startsWith('••••'));
  const secret = await T.tgSecret(token);
  const sent = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (u, o) => { if (String(u).includes('api.telegram.org')) { sent.push(JSON.parse(o.body)); return new Response(JSON.stringify({ ok: true, result: { username: 'catbot' } })); } return realFetch(u, o); };
  const hook = async (text, from, hdr = secret) => req('/tg/' + secret, { method:'POST', headers: { 'x-telegram-bot-api-secret-token': hdr }, body:{ message: { chat: { id: 42 }, from: { id: from }, text } } });
  check('wrong secret header → 403', (await hook('/users', 42, 'nope')).status === 403);
  await hook('/users', 7); check('non-admin is refused', sent.pop().text.includes('not allowed'));
  await hook('/add tguser 30', 42); const added = sent.pop(); check('/add creates user and returns links', added.text.includes('created') && added.text.includes('/u/'));
  await hook('/users', 42); check('/users lists tguser', sent.pop().text.includes('tguser'));
  await hook('/renew tguser 10', 42); check('/renew answers', sent.pop().text.includes('🔁'));
  await hook('/country de', 42); check('/country sets preferred', sent.pop().text.includes('DE') && (await (await req('/api/countries', { headers: auth })).json()).preferred === 'DE');
  await hook('/del tguser', 42); check('/del removes', sent.pop().text.includes('deleted'));
  const wh = await (await req('/api/telegram/webhook', { method:'POST', headers: auth })).json();
  check('webhook registration posts setWebhook with secret', wh.ok && wh.bot==='catbot' && sent.some(b => b.url && b.url.endsWith('/tg/' + secret) && b.secret_token === secret));
  globalThis.fetch = realFetch;
  await req('/api/countries', { method:'PUT', headers: auth, body:{ country:'' } });
  await req('/api/settings', { method:'PUT', headers: auth, body:{ tgToken: '', tgAdmins: [] } });
  check('tg can be switched off', !(await (await req('/api/telegram', { headers: auth })).json()).configured);
}
// pinned ip:port (scan → panel: address emitted only on its verified port)
{
  const st = T.normalizeSettings({ ips: ['198.51.100.7:2053'], tlsPorts: [443], plainEnabled: false, useDefaults: false, includeHost: false, entryLimit: 50 });
  const { entries } = T.buildConfigEntries(HOST, ENV, st, MASTER, null, {});
  // Scanner-imported `ip:port` must connect to the BARE ip — the scanned port is
  // the entry port. `[1.2.3.4:443]:443` links could never dial (the "sent IPs
  // never sit in the configs" bug).
  const mine = entries.filter((e) => e.addr === '198.51.100.7');
  check('pinned addr emits configs', mine.length > 0);
  check('pinned addr only on its scanned port (2053)', mine.length > 0 && mine.every((e) => e.port === 2053), JSON.stringify(mine.map((e) => e.port)));
  check('pinned addr is bare ip in entries', mine.length > 0 && mine.every((e) => e.addr === '198.51.100.7'), JSON.stringify(mine.map((e) => e.addr)));
  check('pinned addr links dial ip:port once (no bracketed [ip:port]:port)', mine.every((e) => e.link.includes('@198.51.100.7:2053?') && !e.link.includes('[198.51.100.7')), mine[0] && mine[0].link.slice(0, 90));
  const st6 = T.normalizeSettings({ ips: ['[2001:db8::1]:8443'], tlsPorts: [443], plainEnabled: false, useDefaults: false, includeHost: false, entryLimit: 50 });
  const { entries: e6 } = T.buildConfigEntries(HOST, ENV, st6, MASTER, null, {});
  const mine6 = e6.filter((e) => String(e.addr).includes('2001:db8::1'));
  check('pinned ipv6 bare in entries, bracketed once in link', mine6.length > 0 && mine6.every((e) => e.addr === '2001:db8::1' && e.link.includes('@[2001:db8::1]:8443?')), mine6[0] && mine6[0].link.slice(0, 90));
  // ?fam=v4|v6 — strict address-family filter (scanner categories / builder)
  {
    const stf = T.normalizeSettings({ ips: ['198.51.100.7:2053', '[2001:db8::2]:8443'], tlsPorts: [443], plainEnabled: false, useDefaults: false, includeHost: false, entryLimit: 50 });
    const q4 = T.buildConfigEntries(HOST, ENV, stf, MASTER, null, { fam: 'v4' });
    check('fam=v4 keeps only raw IPv4', q4.entries.length > 0 && q4.entries.every((e) => /^(\d{1,3}\.){3}\d{1,3}$/.test(String(e.addr))), JSON.stringify(q4.entries.map((e) => e.addr)));
    const q6 = T.buildConfigEntries(HOST, ENV, stf, MASTER, null, { fam: 'v6' });
    check('fam=v6 keeps only raw IPv6', q6.entries.length > 0 && q6.entries.every((e) => String(e.addr).includes(':')), JSON.stringify(q6.entries.map((e) => e.addr)));
    check('subQuery parses fam', T.subQuery(new URL('https://x/sub?fam=v6')).fam === 'v6');
  }
  // /api/events — owner-visible ring log (real actions only)
  {
    for (let i = 0; i < 55; i++) await req('/api/events', { method: 'POST', headers: auth, body: { ev: 'test', d: 'e' + i } });
    const r = await req('/api/events', { headers: auth });
    const j = await r.json();
    check('events ring caps at 50, newest first', j.ok && j.events.length === 50 && j.events[0].ev === 'test' && j.events[0].d === 'e54', String(j.events.length) + '/' + (j.events[0] && j.events[0].d));
  }
  // ================= fixed IPs (pinnedIps) =================
  {
    await req('/api/ips', { method: 'POST', headers: auth, body: { ips: ['6.6.6.6', '5.5.5.5', '7.7.7.7'], replace: true } });
    await req('/api/settings', { method: 'PUT', headers: auth, body: { country: '', pinnedIps: ['6.6.6.6:443'], subRotate: 'fetch' } });
    const sp = (await (await req('/api/settings', { headers: auth })).json()).settings;
    check('pinnedIps stored bare (port stripped, max 5)', JSON.stringify(sp.pinnedIps) === '["6.6.6.6"]', JSON.stringify(sp.pinnedIps));
    let lead = true;
    for (let i = 0; i < 6; i++) {
      const b = await (await req('/sub/' + MASTER + '?limit=48', { env: ENV })).text();
      const first = (b.split('\n')[0] || '');
      if (!first.includes('@6.6.6.6:443')) { lead = false; break; }
    }
    check('pinned fixed IP leads EVERY fetch-rotated sub', lead);
    const pinnedSub = await (await req('/sub/' + MASTER + '?limit=48', { env: ENV })).text();
    check('pinned config carries flag/country tags untouched', pinnedSub.includes('@6.6.6.6:443'));
    await req('/api/settings', { method: 'PUT', headers: auth, body: { pinnedIps: [] } });
    const sp2 = (await (await req('/api/settings', { headers: auth })).json()).settings;
    check('unpin clears list', sp2.pinnedIps.length === 0);
    check('pinnedIps normalize: junk dropped, max 5 kept', T.normalizeSettings({ pinnedIps: ['junk', '1.2.3.4:8443', '[2606:4700::1]:443', 'cdn.example.com', '5.5.5.5', '6.6.6.6', '7.7.7.7', '8.8.8.8'] }).pinnedIps.length === 5);
  }
  // ================= ECH (?ech=1 → &ech= on TLS links) =================
  {
    check('subQuery parses ech', T.subQuery(new URL('https://x/sub?ech=1')).ech === true && T.subQuery(new URL('https://x/sub')).ech === false);
    const ste = T.normalizeSettings({ echList: 'AAH+BASE64ECH==', tlsPorts: [443], plainEnabled: false, useDefaults: false, includeHost: false, entryLimit: 10 });
    const { entries: ee } = T.buildConfigEntries(HOST, ENV, ste, MASTER, null, {});
    const tlsEntry = ee.find((e) => e.tls);
    check('ECH injected into TLS links', tlsEntry && decodeURIComponent(tlsEntry.link).includes('ech=AAH+BASE64ECH=='), tlsEntry && tlsEntry.link.slice(0, 160));
    const plain = ee.find((e) => !e.tls);
    check('ECH never on plain links', !plain || !decodeURIComponent(plain.link).includes('ech='));
    const noEch = T.buildConfigEntries(HOST, ENV, T.normalizeSettings({ tlsPorts: [443], plainEnabled: false, useDefaults: false, includeHost: false, entryLimit: 10 }), MASTER, null, {}).entries[0];
    check('no ech param by default', !decodeURIComponent(noEch.link).includes('ech='));
  }
  // ================= WARP-in-WARP + external subs (round 26) =================
  {
    const w0 = T.normalizeSettings({});
    check('warp defaults off + extSubs empty', w0.warp.mode === 'off' && Array.isArray(w0.extSubs) && w0.extSubs.length === 0);
    check('warp normalize: junk keys kept shape-safe', (() => { const w = T.normalizeSettings({ warp: { mode: 'chain', secretKey: 'x'.repeat(200), publicKey: 'pub123', reserved: '12,34,999,abc,56', endpoint: '' } }).warp; return w.mode === 'chain' && w.secretKey.length === 64 && w.reserved === '12,34,56' && w.endpoint.includes('engage.cloudflareclient.com:2408'); })());
    check('warp off => no outbounds', T.buildWarpOutbounds(T.normalizeSettings({})).length === 0);
    const won = T.buildWarpOutbounds(T.normalizeSettings({ warp: { mode: 'on', secretKey: 'SK==', publicKey: 'PK==', reserved: '1,2,3' } }));
    check('warp on => single wireguard outbound w/ reserved array', won.length === 1 && won[0].tag === 'warp' && won[0].settings.peers[0].publicKey === 'PK==' && won[0].settings.reserved.every((n) => Number.isInteger(n) && n >= 0 && n <= 255) && won[0].streamSettings.sockopt.dialerProxy === undefined, JSON.stringify(won).slice(0, 200));
    const wch = T.buildWarpOutbounds(T.normalizeSettings({ warp: { mode: 'chain', secretKey: 'SK==', publicKey: 'PK==' } }));
    check('warp chain => hub + inner dialerProxy', wch.length === 2 && wch[0].tag === 'warp' && wch[0].streamSettings.sockopt.dialerProxy === 'warp-hub' && wch[1].tag === 'warp-hub', JSON.stringify(wch).slice(0, 200));
    const sw = T.normalizeSettings({ warp: { mode: 'on', secretKey: 'SK==', publicKey: 'PK==' }, useDefaults: false, includeHost: false, entryLimit: 4, tlsPorts: [443] });
    const xc = T.buildXrayConfigs(HOST, ENV, sw, MASTER, null, {});
    check('xray config dials through warp (sockopt dialerProxy)', xc.length > 0 && JSON.stringify(xc[0]).includes('"dialerProxy":"warp"'), xc[0] && JSON.stringify(xc[0]).slice(0, 260));
    const xcCh = T.buildXrayConfigs(HOST, ENV, T.normalizeSettings({ warp: { mode: 'chain', secretKey: 'SK==', publicKey: 'PK==' }, useDefaults: false, includeHost: false, entryLimit: 4, tlsPorts: [443] }), MASTER, null, {});
    check('chain mode: warp-hub present + inner dialerProxy', JSON.stringify(xcCh[0]).includes('"warp-hub"') && JSON.stringify(xcCh[0]).includes('"dialerProxy":"warp-hub"'));
    check('subQuery parses noext', T.subQuery(new URL('https://x/sub?noext=1')).noext === true && T.subQuery(new URL('https://x/sub')).noext === false);
    const exts = T.normalizeSettings({ extSubs: [{ name: '', url: 'http://insecure.dev/x' }, { name: 'ok', url: 'https://ok.dev/sub' }, { name: 'x'.repeat(50), url: 'https://ok2.dev/s' }, { name: 'n3', url: 'ftp://nope' }] });
    check('extSubs normalize: https-only, caps, name default', exts.extSubs.length === 2 && exts.extSubs[0].name === 'ok' && exts.extSubs[1].name.length <= 40, JSON.stringify(exts.extSubs));
    const uris = T.parseExtUris(Buffer.from('vless://a@1.2.3.4:443?id=x#one\nvless://b@5.6.7.8:443?id=y#two\njunk-line-without-scheme\n' + 'vless://c@9.9.9.9:443?id=z#three').toString('base64'));
    check('parseExtUris: b64, scheme filter, cap 100', uris.length === 3 && uris[0].startsWith('vless://') && (() => { const many = T.parseExtUris(Array.from({ length: 150 }, (_, i) => 'vless://x@1.1.1.1:443?id=' + i + '#c' + i).join('\n')); return many.length === 100; })());
    check('/ext route gated without key', (await (await req('/ext/1', { env: ENV })).status) === 404);
    check('/ext unknown index => 404', (await (await req('/ext/5/' + MASTER, { env: ENV })).status) === 404);
    await req('/api/settings', { method: 'PUT', headers: auth, body: { extSubs: [{ name: 'test', url: 'https://test.invalid/sub' }] } });
    const subNoExt = await (await req('/sub/' + MASTER + '?noext=1', { env: ENV })).text();
    check('sub still works with extSubs + noext', subNoExt.split('\n')[0].includes('vless://'));
    check('sub without noext survives dead ext sub (allSettled)', ((await (await req('/sub/' + MASTER, { env: ENV })).text()).split('\n')[0] || '').includes('vless://'));
    const extRoute = await req('/ext/1/' + MASTER, { env: ENV });
    check('/ext/<n>/<uuid> fetches (or clean-fails offline)', extRoute.status === 200 ? (extRoute.headers.get('subscription-userinfo') || '').includes('total=0') : extRoute.status === 502, extRoute.status);
    await req('/api/settings', { method: 'PUT', headers: auth, body: { extSubs: [] } });
  }
  // ================= /api/version contract (app PanelUpdate recognition) =================
  {
    const v = await (await req('/api/version', { env: ENV })).json();
    check('version contract: anonymous gets panel+version (PanelUpdate.kt requires them)', v.ok === true && v.panel === 'cat-panel' && /^[0-9]+\.[0-9]+\.[0-9]+$/.test(v.version), JSON.stringify(v));
  }
  // ================= ProxyIP pool → connection addresses (toAddrs) =================
  {
    const pre = ((await (await req('/api/settings', { headers: auth })).json()).settings.ips || []).length;
    // Fresh empty cache BEFORE the first call: with a stale cache the route
    // fires a LIVE proxyRepoRefresh (CI has open network) and the pool stops
    // being empty mid-test — sandbox (no outbound) hides this.
    await KV.put('cat_prepo_cache_v1', JSON.stringify({ ts: Date.now(), per: {}, ips: [] }));
    const empty = await (await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'toAddrs' } })).json();
    check('toAddrs with empty pool adds nothing', empty.ok === true && empty.added === 0, JSON.stringify(empty));
    await KV.put('cat_prepo_cache_v1', JSON.stringify({ ts: Date.now(), per: {}, ips: ['5.75.200.40#DE', '45.12.30.10#TR', 'not-an-ip'] }));
    const imp = await (await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'toAddrs', limit: 64 } })).json();
    check('toAddrs imports healthy pool with country tags', imp.ok === true && imp.added === 2, JSON.stringify(imp));
    const st = (await (await req('/api/settings', { headers: auth })).json()).settings;
    check('imported pool IPs stored PORT-PINNED + tagged', st.ips.includes('5.75.200.40:443') && st.ips.includes('45.12.30.10:443') && st.ipCountries['5.75.200.40:443'] === 'DE' && st.ipCountries['45.12.30.10:443'] === 'TR', JSON.stringify(st.ips));
    check('toAddrs dedupes (second run adds 0)', ((await (await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'toAddrs' } })).json()).added) === 0);
    check('ips list grew by exactly 2', ((await (await req('/api/settings', { headers: auth })).json()).settings.ips.length) === pre + 2);
    // ?limit=200 so early entryLimit:10 fixture + rotation shuffle cannot push
    // the freshly imported addresses out of the emitted window.
    const dbg = await (await req('/sub/' + MASTER + '?limit=200', { env: ENV })).text();
    check('pool IP gets a config in the sub', dbg.includes('@5.75.200.40:'), dbg.split('\n').length + ' lines');
    await KV.put('cat_prepo_cache_v1', JSON.stringify({ ts: Date.now(), per: {}, ips: [] }));
  }
  // ================= telegram deploy bot (round 29) =================
  {
    check('gh settings normalize: junk dropped, default workflow kept', (() => { const s = T.normalizeSettings({ ghPat: 'nope', ghRepo: 'no repo', ghRef: 'bad ref!', ghWorkflow: 'x.txt' }); return !s.ghPat && !s.ghRepo && !s.ghRef && s.ghWorkflow === 'deploy-worker.yml'; })());
    check('gh settings normalize: valid values kept', (() => { const s = T.normalizeSettings({ ghPat: 'github_pat_ABCDEFGHIJKLMNOPQRSTUVWX', ghRepo: 'o/r', ghRef: 'main', ghWorkflow: 'deploy-worker.yml' }); return s.ghPat.startsWith('github_pat_') && s.ghRepo === 'o/r' && s.ghRef === 'main'; })());
    const base = { origin: 'https://x', host: 'x', env: ENV, settings: T.normalizeSettings({}), masterUuid: MASTER };
    const uncfg = await T.tgCommand('/deploy', base);
    check('/deploy honest without config (no CF token asked)', uncfg.includes('not configured') && !uncfg.includes('Cloudflare API token is NEVER'.toLowerCase()) ? uncfg.includes('NEVER stored') || uncfg.includes('not configured') : true, uncfg.slice(0, 80));
    check('/deploy never asks for a CF token', !uncfg.includes('CLOUDFLARE_API_TOKEN=') && uncfg.includes('GitHub'));
    const cfgd = T.normalizeSettings({ ghPat: 'github_pat_ABCDEFGHIJKLMNOPQRSTUVWX', ghRepo: 'o/r' });
    let captured = null;
    const realFetch = globalThis.fetch;
    globalThis.fetch = async (u, o) => { captured = { url: String(u), method: o && o.method, body: o && o.body }; return { ok: true, status: 204, json: async () => ({}) }; };
    try {
      const q = await T.tgCommand('/deploy', Object.assign({}, base, { settings: cfgd }));
      check('/deploy dispatches workflow on default ref', q.includes('queued') && captured.url === 'https://api.github.com/repos/o/r/actions/workflows/deploy-worker.yml/dispatches' && JSON.parse(captured.body).ref === 'main' && captured.method === 'POST', captured.url);
      check('/deploy branch arg overrides ref', ((await T.tgCommand('/deploy arena/01a0ebed-cat-client', Object.assign({}, base, { settings: cfgd }))).includes('queued')) && JSON.parse(captured.body).ref === 'arena/01a0ebed-cat-client');
      globalThis.fetch = async () => ({ ok: false, status: 404, json: async () => ({ message: 'Not Found' }) });
      const e404 = await T.tgCommand('/deploy', Object.assign({}, base, { settings: cfgd }));
      check('/deploy maps 404 to a clear error', e404.includes('404') && e404.includes('not found'));
      globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ workflow_runs: [{ status: 'completed', conclusion: 'success', head_branch: 'main', run_number: 7, html_url: 'https://x/1' }, { status: 'in_progress', conclusion: null, head_branch: 'main', run_number: 8, html_url: 'https://x/2' }] }) });
      const list = await T.tgCommand('/deploys', Object.assign({}, base, { settings: cfgd }));
      check('/deploys lists runs with status marks', list.includes('✅') && list.includes('⏳') && list.includes('main') && list.includes('#7'));
    } finally { globalThis.fetch = realFetch; }
    await req('/api/settings', { method: 'PUT', headers: auth, body: { ghRepo: 'o/r', ghPat: 'github_pat_ABCDEFGHIJKLMNOPQRSTUVWX' } });
    const masked = ((await (await req('/api/settings', { headers: auth })).json()).settings.ghPat || '');
    check('ghPat stored but masked in API', masked.startsWith('••••'), masked);
    const roundTrip = await (await req('/api/settings', { method: 'PUT', headers: auth, body: { ghRepo: 'o/r', ghPat: masked, ghRef: 'main' } })).json();
    check('masked ghPat on PUT does not wipe stored token', roundTrip.settings.ghPat.startsWith('••••'));
    await req('/api/settings', { method: 'PUT', headers: auth, body: { ghRepo: '', ghPat: '', ghRef: '' } });
    check('gh fields cleared on empty PUT', ((await (await req('/api/settings', { headers: auth })).json()).settings.ghRepo === ''));
  }
  // ================= auto config rotation (subRotate) =================
  {
    check('subRotate defaults to fetch (fresh set every update)', T.normalizeSettings({}).subRotate === 'fetch' && T.normalizeSettings({ subRotate: 'daily' }).subRotate === 'daily');
    await req('/api/settings', { method: 'PUT', headers: auth, body: { subRotate: 'fetch' } });
    const firsts = new Set();
    // A short random sample had a measurable chance of picking the same first
    // node every time despite healthy fetch-rotation; sample more updates so
    // the assertion tests the feature instead of unlucky randomness.
    for (let i = 0; i < 32; i++) {
      const b = await (await req('/sub/' + MASTER + '?limit=48', { env: ENV })).text();
      firsts.add((b.split('\n')[0] || '').split('@')[1] || '');
    }
    check('rotate=fetch: sub changes across refreshes', firsts.size >= 2, 'unique first-lines=' + firsts.size);
    const daily1 = await (await req('/sub/' + MASTER + '?rotate=daily', { env: ENV })).text();
    const daily2 = await (await req('/sub/' + MASTER + '?rotate=daily', { env: ENV })).text();
    check('rotate=daily: deterministic within the day', daily1 === daily2 && daily1.length > 0);
    const stable1 = await (await req('/sub/' + MASTER + '?rotate=off', { env: ENV })).text();
    const stable2 = await (await req('/sub/' + MASTER + '?rotate=off', { env: ENV })).text();
    check('rotate=off: stable order', stable1 === stable2);
    const offFirst = (await (await req('/sub/' + MASTER + '?rotate=off&limit=1', { env: ENV })).text()).trim();
    check('rotation keeps port walk: first config is TLS :443', offFirst.includes(':443?') && offFirst.includes('security=tls'), offFirst.slice(0, 90));
  }
  // Legacy panels saved repoAuto=false solely because beta92's default was opt-in.
  // Upgrade once to on, but keep a recorded explicit OFF choice.
  {
    const legacyKv = new FakeKV();
    await legacyKv.put(T.KV_KEYS.settings, JSON.stringify({ repoAuto: false }));
    T.kvCacheClear();
    const migrated = await T.readSettings({ CAT_KV: legacyKv });
    const saved = JSON.parse(await legacyKv.get(T.KV_KEYS.settings));
    check('legacy default-off feed setting migrates to auto-on once', migrated.repoAuto === true && migrated.repoAutoDefaultMigrated === true && saved.repoAuto === true && saved.repoAutoDefaultMigrated === true);

    const optedOutKv = new FakeKV();
    await optedOutKv.put(T.KV_KEYS.settings, JSON.stringify({ repoAuto: false }));
    await optedOutKv.put('cat_events_v1', JSON.stringify([{ ev: 'repo-auto', d: 'off', t: Date.now() }]));
    T.kvCacheClear();
    const optedOut = await T.readSettings({ CAT_KV: optedOutKv });
    check('legacy explicit feed-off choice remains off after migration', optedOut.repoAuto === false && optedOut.repoAutoDefaultMigrated === true);
    T.kvCacheClear();
  }
  // ================= repo library: 12h feeds + dead replacement =================
  {
    const fakeFeed = async (url) => {
      if (String(url).includes('arista')) return { ok: true, status: 200, text: async () => '198.51.10.1\n198.51.10.1\n198.51.10.2\n#comment\njunk line\n198.51.10.3#DE\n' };
      return { ok: true, status: 200, text: async () => JSON.stringify({ results: [{ ip: '198.51.20.1', ms: 40, status: 'online' }, { ip: '198.51.20.2', ms: 9, status: 'online' }, { ip: '198.51.20.3', ms: 5, status: 'down' }] }) };
    };
    const rep = await T.refreshRepos(ENV, fakeFeed);
    check('repo refresh merges both feeds, uniq + junk-filtered', rep.ok && rep.total === 5, JSON.stringify(rep.per));
    const st = await req('/api/repos', { headers: auth });
    const j = await st.json();
    check('/api/repos GET status + auto-on default', j.ok && j.total === 5 && Array.isArray(j.repos) && j.repos.length >= 2 && j.auto === true, 'total=' + j.total + ', auto=' + j.auto);
    check('repoAuto defaults on but keeps explicit opt-out', T.defaultSettings().repoAuto === true && T.normalizeSettings({}).repoAuto === true && T.normalizeSettings({ repoAuto: false }).repoAuto === false);
    const pool0 = (await T.repoHealthyPool(ENV, 10)).map((p) => p.ip);
    check('json-speed sort within feed: fastest first', pool0.indexOf('198.51.20.2') < pool0.indexOf('198.51.20.1'), JSON.stringify(pool0));
    // dead reports: <3 = kept, >=3 = dropped and replaced on next refresh
    await req('/api/repos', { method: 'POST', headers: auth, body: { action: 'health', dead: ['198.51.10.1'] } });
    await req('/api/repos', { method: 'POST', headers: auth, body: { action: 'health', dead: ['198.51.10.1'] } });
    const poolAfter2 = (await T.repoHealthyPool(ENV, 10)).map((p) => p.ip);
    check('dead<3 still in pool', poolAfter2.includes('198.51.10.1'));
    const hr = await (await req('/api/repos', { method: 'POST', headers: auth, body: { action: 'health', dead: ['198.51.10.1'] } })).json();
    const poolAfter3 = (await T.repoHealthyPool(ENV, 10)).map((p) => p.ip);
    check('dead≥3 dropped from pool', hr.dropped === 1 && !poolAfter3.includes('198.51.10.1') && poolAfter3.length === 4, JSON.stringify(poolAfter3));
    const subDefaultAuto = await (await req('/sub/' + MASTER + '?limit=200', { env: ENV })).text();
    check('default-on repoAuto appends feed IPs to the subscription', subDefaultAuto.includes('@198.51.20.2:443') || subDefaultAuto.includes('@198.51.10.2:443') || subDefaultAuto.includes('@198.51.10.3:443') || subDefaultAuto.includes('@198.51.20.1:443'));
    // repoAuto → sub gains library IPs (pinned :443), off/norepo → not
    await req('/api/settings', { method: 'PUT', headers: auth, body: { repoAuto: true } });
    const subAuto = await (await req('/sub/' + MASTER + '?limit=200&norepo=0', { env: ENV })).text();
    check('repoAuto on → library IP (pinned 443) in sub', subAuto.includes('vless://') && /[198.51.20.2|198.51.10.2|198.51.10.3|198.51.20.1]/.test('') === false && (subAuto.includes('@198.51.20.2:443') || subAuto.includes('@198.51.10.2:443') || subAuto.includes('@198.51.10.3:443') || subAuto.includes('@198.51.20.1:443')));
    const subNo = await (await req('/sub/' + MASTER + '?limit=200&norepo=1', { env: ENV })).text();
    check('?norepo=1 excludes library IPs', !subNo.includes('@198.51.'));
    await req('/api/settings', { method: 'PUT', headers: auth, body: { repoAuto: false } });
    const subOff = await (await req('/sub/' + MASTER + '?limit=200', { env: ENV })).text();
    check('repoAuto off → no library IPs', !subOff.includes('@198.51.'));
    // import by country (tagged txt feed entry 198.51.10.3#DE)
    const imp = await (await req('/api/repos', { method: 'POST', headers: auth, body: { action: 'import', cc: 'DE', limit: 8 } })).json();
    check('repo import by country adds to panel list', imp.ok && imp.added >= 1, JSON.stringify(imp));
    // sanitize: custom repo kept, junk url rejected, defaults on empty
    const san = T.sanitizeRepos([{ id: 'mine', name: 'x', url: 'https://example.com/l.txt', kind: 'txt' }, { url: 'ftp://bad' }]);
    check('sanitizeRepos: https-only, defaults when empty', san.length === 1 && san[0].id === 'mine' && T.sanitizeRepos(null).length >= 2);
  }
  // ================= ProxyIP repo library =================
  {
    const fakeFeed = async (url) => {
      if (String(url).includes('xgonce')) return { ok: true, status: 200, text: async () => 'IP,cf-meta-ip,PORT,spd,CC,COLO,TCPms,TLSms\n198.51.30.1,x,443,200,US,EWR,12.5,20\n198.51.30.2,x,443,300,DE,YYZ,30.1,25\nbadrow' };
      if (String(url).toLowerCase().includes('gb')) return { ok: true, status: 200, text: async () => '#top\n198.51.40.1\n198.51.40.1\nproxy.example.org\n' };
      return { ok: true, status: 200, text: async () => '198.51.41.9\njunk\n' };
    };
    const rep = await T.refreshProxyRepos(ENV, fakeFeed);
    check('proxy repo refresh: csv+txt merged, uniq', rep.ok && rep.total === 5, JSON.stringify(rep.per));
    const pj = await (await req('/api/prepos', { headers: auth })).json();
    check('/api/prepos GET status', pj.ok && pj.total === 5 && pj.repos.length >= 3, 'total=' + pj.total);
    const pool = (await T.proxyRepoHealthyPool(ENV, 10)).map((p) => p.ip);
    check('csv-proxy speed sort: fastest first', pool.indexOf('198.51.30.1:443') < pool.indexOf('198.51.30.2:443'), JSON.stringify(pool));
    check('csv port column preserved (real port wins over 443)', pool.includes('198.51.30.1:443'), JSON.stringify(pool));
    check('proxy domains kept (port-pinned)', pool.includes('proxy.example.org:443'));
    // dead replacement ×3
    await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'health', dead: ['198.51.41.9'] } });
    await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'health', dead: ['198.51.41.9'] } });
    const pool2 = (await T.proxyRepoHealthyPool(ENV, 10)).map((p) => p.ip);
    check('proxy dead<3 kept', pool2.includes('198.51.41.9:443'));
    const hr = await (await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'health', dead: ['198.51.41.9'] } })).json();
    const pool3 = (await T.proxyRepoHealthyPool(ENV, 10)).map((p) => p.ip);
    check('proxy dead≥3 dropped', hr.dropped === 1 && !pool3.includes('198.51.41.9:443'));
    // import → settings.proxyIps
    const imp = await (await req('/api/prepos', { method: 'POST', headers: auth, body: { action: 'import', cc: 'US', limit: 8 } })).json();
    check('proxy import by country', imp.ok && imp.added >= 1 && imp.total >= 1, JSON.stringify(imp));
    // auto-append to sub (?proxyip= entries), ?norepo=1 opt-out, off default
    await req('/api/settings', { method: 'PUT', headers: auth, body: { proxyRepoAuto: true, proxyIps: ['203.0.113.1'] } });
    const subAuto = await (await req('/sub/' + MASTER + '?norepo=0', { env: ENV })).text();
    // port-bearing relay: colon is double-encoded in the raw link (%253A)
    check('proxyRepoAuto on → appended port-pinned ProxyIP in sub', /proxyip(?:%3D|=)198\.51\.30\.1(?:%253A|%3A|:)443/.test(subAuto), 'searched');
    // and the WORKER still dials it correctly after double-decode (unit)
    const dialPath = '/vl/TOKEN?ed=2560?proxyip=198.51.30.1%253A443';
    const pxo = ((dialPath.match(/[?&](?:proxyip|pyip)=([^&]+)/) || [])[1] || '');
    let dec = pxo; try { dec = decodeURIComponent(dec); } catch (e) { } try { dec = decodeURIComponent(dec); } catch (e) { }
    check('pxOverride double-decode → host:port', dec === '198.51.30.1:443', dec);
    const subNo = await (await req('/sub/' + MASTER + '?norepo=1', { env: ENV })).text();
    check('?norepo=1 excludes repo ProxyIPs', !subNo.includes('proxyip%3D198.51.'));
    check('user own ProxyIP still present', subNo.includes('proxyip%3D203.0.113.1'));
    await req('/api/settings', { method: 'PUT', headers: auth, body: { proxyRepoAuto: false } });
    const subOff = await (await req('/sub/' + MASTER, { env: ENV })).text();
    check('proxyRepoAuto off → no repo ProxyIPs', !subOff.includes('proxyip%3D198.51.'));
    check('sanitizeProxyRepos: kinds + https-only', T.sanitizeProxyRepos([{ id: 'm', url: 'https://x/a.csv', kind: 'csv-proxy' }]).length === 1 && T.sanitizeProxyRepos(null).length >= 3);
    // ---- port chain: feed port → cache → healthy pool (default 443) ----
    const portFeed = async (url) => ({ ok: true, status: 200, text: async () => 'IP,cf,PORT,spd,CC\n198.51.60.1,x,8443,10,DE\n198.51.60.2,x,,5,US\n' });
    await T.refreshProxyRepos(ENV, portFeed);
    const pp = (await T.proxyRepoHealthyPool(ENV, 20));
    check('csv PORT column survives: real port pinned', pp.some((p) => p.ip === '198.51.60.1:8443' && p.cc === 'DE'), JSON.stringify(pp));
    check('missing csv port → default pin 443', pp.some((p) => p.ip === '198.51.60.2:443'));
    // ---- per-ProxyIP configs (screenshot style) + repo default country ----
    check('proxyRepoAuto defaults ON', T.normalizeSettings({}).proxyRepoAuto === true && T.normalizeSettings({ proxyRepoAuto: false }).proxyRepoAuto === false);
    const sanc = T.sanitizeProxyRepos([{ id: 'w', name: 'wanwu', url: 'https://x/DE.txt', kind: 'txt', cc: 'de' }]);
    check('repo default country kept (sanitized)', sanc[0].cc === 'DE');
    const feedCC = async (url) => ({ ok: true, status: 200, text: async () => '198.51.50.7\n198.51.50.8\n' });
    await req('/api/settings', { method: 'PUT', headers: auth, body: { proxyRepos: [{ id: 'wde', name: 'wanwu-de', url: 'https://x/DE.txt', kind: 'txt', cc: 'DE' }], proxyRepoAuto: true } });
    await T.refreshProxyRepos(ENV, feedCC);
    const poolCC = (await T.proxyRepoHealthyPool(ENV, 10)).find((p) => p.ip === '198.51.50.7:443');
    check('txt feed gets repo default country tag', poolCC && poolCC.cc === 'DE', JSON.stringify(poolCC));
    // beta94: the Android scanner pulls the panel's own pool from /api/prepos, so the
    // endpoint must return the relays themselves (ip:port#CC), not just statistics.
    {
      const prepos = await (await req('/api/prepos', { headers: auth })).json();
      check('prepos: returns the pool as ip:port#CC for the app scanner',
        Array.isArray(prepos.ips) && prepos.ips.some((x) => /^198\.51\.50\.7:443(#[A-Z]{2})?$/.test(String(x))),
        JSON.stringify(prepos.ips));
      check('prepos: pool entries keep their country tag', prepos.ips.some((x) => String(x).includes('#DE')), JSON.stringify(prepos.ips));
    }
    const stpx = T.normalizeSettings({ lang: 'fa', proxyIps: ['203.0.113.1'], proxyCountries: { '203.0.113.1': 'DE' }, useDefaults: false, includeHost: false, tlsPorts: [443], plainEnabled: false });
    const { entries: epx } = T.buildConfigEntries(HOST, ENV, stpx, MASTER, null, {});
    const pxs = epx.filter((e) => e.name.includes('🎯'));
    // beta94: the relay carries its default port, and its country tag moved with it.
    check('per-ProxyIP configs: numbered + flag + Persian country', pxs.length === 2 && pxs[0].name === '🎯 1. 🇩🇪 آلمان · 203.0.113.1:443', pxs[0] && pxs[0].name);
    { // spoofing is opt-in: the rotation pool (and the ' · <sni>' remark suffix) only exist while sniFront is on
      const stf = T.normalizeSettings({ lang: 'fa', proxyIps: ['203.0.113.1'], proxyCountries: { '203.0.113.1': 'DE' }, useDefaults: false, includeHost: false, tlsPorts: [443], plainEnabled: false, sniFront: true });
      const pxf = T.buildConfigEntries(HOST, ENV, stf, MASTER, null, {}).entries.filter((e) => e.name.includes('🎯'));
      check('per-ProxyIP configs keep the SNI remark suffix while spoofing is on', pxf.length === 2 && pxf[0].name.startsWith('🎯 1. 🇩🇪 آلمان · 203.0.113.1:443 · '), pxf[0] && pxf[0].name); }
    // Path params must be real query params: one '?' only, `ed` and `proxyip`
    // as separate entries (a second '?' — «?ed=2560?proxyip=…» — made the relay
    // override unparseable for every client; regression-pinned in link-shape.test.mjs).
    check('PX config carries a parseable proxyip relay path', pxs.every((e) => {
      const enc = e.link.split('#')[0];
      const pathVal = (enc.match(/[?&]path=([^&]*)/) || [])[1] || '';
      const wsPath = decodeURIComponent(pathVal);
      const query = wsPath.split('?')[1];
      if (!query || (wsPath.match(/\?/g) || []).length !== 1) return false;
      const params = new Map(query.split('&').map((kv) => [kv.split('=')[0], kv.split('=').slice(1).join('=')]));
      // The relay rides inside a query param, so a ':' arrives double-encoded
      // («%253A»); the worker decodes it twice by design — the test mirrors that.
      return decodeURIComponent(String(params.get('proxyip') || '')) === '203.0.113.1:443' && params.has('ed');
    }), pxs[0] && pxs[0].link);
    const sten = T.normalizeSettings({ lang: 'en', proxyIps: ['203.0.113.1'], proxyCountries: { '203.0.113.1': 'DE' }, useDefaults: false, includeHost: false, tlsPorts: [443], plainEnabled: false });
    const { entries: een } = T.buildConfigEntries(HOST, ENV, sten, MASTER, null, {});
    check('en locale → English country label', een.some((e) => e.name === '🎯 1. 🇩🇪 Germany · 203.0.113.1:443'), een.filter((e) => e.name.includes('🎯'))[0] && een.filter((e) => e.name.includes('🎯'))[0].name);
  }
  check('pinnedPortOf parses v4/v6/domain, rejects bare', T.pinnedPortOf('1.2.3.4:2053') === 2053 && T.pinnedPortOf('[2001:db8::1]:8443') === 8443 && T.pinnedPortOf('2001:db8::1') === 0 && T.pinnedPortOf('www.x.com:2053') === 2053 && T.pinnedPortOf('1.2.3.4') === 0);
  const r = await req('/api/ips', { method: 'POST', headers: auth, body: { ips: ['198.51.100.9:8443#DE', 'not an ip!!'], replace: true } });
  const j = await r.json();
  check('/api/ips stores ip:port + cc, rejects junk', j.ok && j.count === 1 && j.ips[0] === '198.51.100.9:8443');
  await req('/api/ips', { method: 'POST', headers: auth, body: { ips: [], replace: true } });
}
// custom free ports survive normalize (panel no longer locked to presets)
{
  const st2 = T.normalizeSettings({ tlsPorts: [443, 8443, 2096], plainPorts: [80, 8080] });
  check('normalize keeps custom ports', st2.tlsPorts.map(Number).includes(2096) && st2.tlsPorts.map(Number).includes(8443) && st2.plainPorts.map(Number).includes(8080));
}
// SNI: Cloudflare answers an early 403 when the TLS SNI differs from the HTTP Host («domain fronting» is
// blocked), so the DEFAULT SNI of generated configs is the worker host. Spoofing (a different SNI) is strictly
// opt-in (settings.sniFront); it stays fully supported for owners who ask for it.
{
  check('default SNI is the worker host (Cloudflare rejects SNI ≠ Host)', T.effectiveSni(HOST, {}, T.normalizeSettings({})) === HOST.toLowerCase(), T.effectiveSni(HOST, {}, T.normalizeSettings({})));
  check('spoofing is OFF by default (absent in old data ⇒ false)', T.normalizeSettings({}).sniFront === false && T.normalizeSettings({ sniRotate: true, sni: 'example.com' }).sniFront === false);
  check('explicit settings.sni / env.SNI are ignored while spoofing is off', T.effectiveSni(HOST, { SNI: 'env.example' }, T.normalizeSettings({ sni: 'example.com' })) === HOST.toLowerCase());
  check('spoofing on, nothing set → the skk.moe scan/default SNI', T.effectiveSni(HOST, {}, T.normalizeSettings({ sniFront: true })) === 'skk.moe');
  check('SNI: settings beat default (spoofing on)', T.effectiveSni(HOST, {}, T.normalizeSettings({ sni: 'example.com', sniFront: true })) === 'example.com');
  check('SNI: env beats default (spoofing on)', T.effectiveSni(HOST, { SNI: 'env.example' }, T.normalizeSettings({ sniFront: true })) === 'env.example');
  check('scan SNI keeps its own meaning (skk.moe / explicit), independent of the link SNI', T.scanSniOf({}, T.normalizeSettings({})) === 'skk.moe' && T.scanSniOf({}, T.normalizeSettings({ sni: 'example.com' })) === 'example.com');
  const subSt = T.normalizeSettings({});
  const sub = mod ? null : null;
  const { ctx } = T.buildConfigEntries(HOST, ENV, subSt, MASTER, null, {});
  { const html = T.panelPage({ CAT_PANEL_KV: new Map() }, T.defaultSettings(), 'h.example.workers.dev', 'u123');
  check('hero «in use» card on dashboard', html.includes('heroCard') && html.includes('renderHero') && html.includes('hero_inuse'));
  check('panel version is 6.69.0', T.CAT_PANEL_VERSION === '6.69.0');
  // ── Error 1101, second face ────────────────────────────────────────────────
  // The three checks below read the SOURCE, so they only mean anything on the
  // plaintext asset. CI obfuscates that asset IN PLACE and re-runs this whole
  // suite against it (android.yml, the ship-artifact step), so gate on the file's
  // own header comment instead of on its name: the plaintext tab carries
  // «lean single-file», and min/obf/stealth all strip it. Gating on the name alone
  // broke the release build once — the in-place copy is still called
  // catclient.worker.js.
  // «The script will never generate a response»: a handler that returns nothing is
  // its own runtime error, and a try/catch cannot see it (it catches throws, never
  // `undefined`). The guard turns it into a throw so the crash report names the path.
  const isPlainSource = (() => {
    try { return readFileSync(workerPath, 'utf8').includes('lean single-file'); }
    catch { return false; }
  })();
  if (!isPlainSource) {
    console.log('– source-level guard checks skipped (artifact run: ' + workerPath.split('/').pop() + ')');
  } else {
    const src = readFileSync(workerPath, 'utf8');
    check('no-response guard exists (returned-not-a-Response → throw)',
      /if\s*\(\s*!\(res instanceof Response\)\s*\)\s*\{/.test(src) &&
      src.includes('instead of a Response'));
    const guardAt = src.indexOf('res instanceof Response');
    const returnAt = src.indexOf('return res;');
    check('the guard runs BEFORE the handler result is returned', guardAt !== -1 && returnAt !== -1 && guardAt < returnAt);
    check('the guard is inside the try block (its throw lands in the crash path)',
      src.lastIndexOf('try {', guardAt) > src.lastIndexOf('} catch', guardAt - 1) - 1 &&
      src.slice(guardAt, guardAt + 400).includes('throw new Error'));
  }
  { const qs = T.normalizeSettings({ blockQuic: true });
    const yaml = T.buildClashYaml('h.dev', { CAT_PANEL_KV: new Map() }, qs, 'u', null, {});
    check('blockQuic in clash yaml', yaml.includes('NETWORK,udp'), yaml.split('\n').find(l=>l.includes('REJECT')&&l.includes('443'))||'');
    const sb = JSON.stringify(T.buildSingboxConfig('h.dev', { CAT_PANEL_KV: new Map() }, qs, 'u', null, {}));
    check('blockQuic in singbox', sb.includes('"network":"udp"'));
    const xr = JSON.stringify(T.buildXrayConfigs('h.dev', { CAT_PANEL_KV: new Map() }, qs, 'u', null, {}));
    check('blockQuic in xray', xr.includes('"network":"udp"') || xr.includes('"udp"')); }
  const ipv6Pinned = T.normalizeSettings({ ips: ['[2606:4700::1]:2053'], ipCountries: { '[2606:4700::1]:2053': 'DE' }, useDefaults: false, includeHost: false });
  const ipv6PinnedEntries = T.buildConfigEntries(HOST, ENV, ipv6Pinned, MASTER, null, {}).entries;
  check('bracketed IPv6 scan keeps its verified port and country', ipv6Pinned.ipCountries['[2606:4700::1]:2053'] === 'DE' && ipv6PinnedEntries.some((e) => e.addr === '2606:4700::1' && e.port === 2053 && e.cc === 'DE'));
  const prov = T.normalizeSettings({ ipSources: { '9.9.9.9:443': { src: 'scanner', ms: 210, at: 9 } } });
  check('ip provenance (src+ping) persisted', !!(prov.ipSources && prov.ipSources['9.9.9.9:443'] && prov.ipSources['9.9.9.9:443'].src === 'scanner'), JSON.stringify(prov.ipSources));
  {
    const r = await req('/api/ips', { method:'POST', headers: auth, body:{ ips:['198.51.100.77:443#DE'], source:'scanner', pingMs:{ '198.51.100.77:443#DE': 341 } } }); const j = await r.json();
    check('ips import accepted provenance payload', j.ok === true && j.ips.includes('198.51.100.77:443'), JSON.stringify(j.ips));
    const st3 = (await (await req('/api/settings', { headers: auth })).json()).settings;
    check('provenance badge stored (scanner + 341ms)', !!(st3.ipSources && st3.ipSources['198.51.100.77:443#DE'] && st3.ipSources['198.51.100.77:443#DE'].ms === 341), JSON.stringify(st3.ipSources));
    const anon = await req('/api/ip-test', { method:'POST', body:{ ips:['1.2.3.4'] } }); check('ip-test 401 without session', anon.status === 401);
    const emp = await req('/api/ip-test', { method:'POST', headers: auth, body:{ ips: [] } }); const je = await emp.json();
    check('ip-test empty list → empty results', je.ok === true && Object.keys(je.results).length === 0);
    const html2 = T.panelPage({ CAT_PANEL_KV: new Map() }, T.defaultSettings(), 'h.dev', 'u');
    check('worker-side test button on IP list', html2.includes('btnIpTest') && html2.includes('ip_test_btn'));
    // beta45: domain entries resolved to raw CF IPs (DNS-free subs) — cache-first
    await KV.put('cat_dom_v1', JSON.stringify({ 'icook.tw': { ip: '104.20.28.74', ts: Date.now() }, 'www.speedtest.net': { ip: '104.17.147.22', ts: Date.now() } }));
    const env5 = ENV;
    T.kvCacheClear();
    const stD = T.normalizeSettings({ ips: ['icook.tw', 'www.speedtest.net'], includeHost: false, useDefaults: false });
    const mapped = await T.withDomMap(env5, stD);
    const lst = T.addressList('h.dev', env5, mapped);
    check('domain → raw CF IP in sub (DNS-free)', lst.includes('104.20.28.74') && lst.includes('104.17.147.22') && !lst.includes('icook.tw'), JSON.stringify(lst));
    const stOff = await T.withDomMap(env5, T.normalizeSettings({ ips: ['icook.tw'], domToIp: false, useDefaults: false, includeHost: false }));
    check('?dom=1 / domToIp=false keeps domains', T.addressList('h.dev', env5, stOff).includes('icook.tw'));
    const bad = await T.withDomMap(env5, T.normalizeSettings({ ips: ['h.dev'], useDefaults: false, includeHost: false }));
    check('poisoned cache entry ignored (must be CF-range)', !T.addressList('h.dev', env5, bad).includes('6.6.6.6'));
  }
  // beta46: SNI rotation — every TLS config a different fronting SNI (opt-in since 6.54: sniFront)
  {
    const stDef = T.normalizeSettings({ useDefaults: true, includeHost: true, tlsPorts: [443], plainEnabled: false });
    const outDef = T.buildConfigEntries('panelx.workers.dev', ENV, stDef, 'u1', null, {});
    const snisDef = new Set(outDef.entries.filter((e) => e.tls).map((e) => e.sni));
    check('default: every TLS config carries sni == worker host (no rotation)', snisDef.size === 1 && snisDef.has('panelx.workers.dev'), [...snisDef].join(','));
    check('default: no SNI suffix in the remarks', !outDef.entries.filter((e) => e.tls).some((e) => / · /.test(e.name)), outDef.entries[0] && outDef.entries[0].name);
    check('default: sni= in every TLS link equals host=', outDef.entries.filter((e) => e.tls).every((e) => { const sni = decodeURIComponent((e.link.match(/[?&]sni=([^&#]*)/) || [])[1] || ''); const host = decodeURIComponent((e.link.match(/[?&]host=([^&#]*)/) || [])[1] || ''); return sni && sni === host; }));
    const st = T.normalizeSettings({ useDefaults: true, includeHost: true, tlsPorts: [443], plainEnabled: false, sniFront: true });
    const out = T.buildConfigEntries('panelx.workers.dev', ENV, st, 'u1', null, {});
    const vls = out.entries.filter((e) => e.proto === 'vless' && e.tls);
    const snis = vls.map((e) => e.sni);
    const uniqSnis = new Set(snis);
    check('SNI rotation: TLS configs carry >1 distinct SNI', uniqSnis.size > 1, uniqSnis.size + ' distinct: ' + [...uniqSnis].slice(0, 4).join(','));
    check('SNI rotation: pool = defaults, never the panel host', [...uniqSnis].every((x) => T.DEFAULT_SNI_POOL.includes(x)) && !uniqSnis.has('panelx.workers.dev'), [...uniqSnis].join(','));
    check('SNI rotation: remarks carry the SNI suffix', vls.some((e) => / · /.test(e.name)) === true, vls[0] && vls[0].name);
    check('SNI rotation: links carry matching sni= param', vls.every((e) => e.link.includes('sni=' + e.sni)) === true);
    const outP = T.buildConfigEntries('panelx.workers.dev', ENV, st, 'u1', null, { sni: 'time.is' });
    const snisP = new Set(outP.entries.filter((e) => e.tls).map((e) => e.sni));
    check('?sni= pins a single SNI', snisP.size === 1 && snisP.has('time.is'), [...snisP].join(','));
    const stOff = T.normalizeSettings({ useDefaults: true, includeHost: true, tlsPorts: [443], plainEnabled: false, sniFront: true, sniRotate: false });
    const snisOff = new Set(T.buildConfigEntries('panelx.workers.dev', ENV, stOff, 'u1', null, {}).entries.filter((e) => e.tls).map((e) => e.sni));
    check('sniRotate=false → single shared SNI (skk.moe default)', snisOff.size === 1 && snisOff.has('skk.moe'), [...snisOff].join(','));
    const pool = T.sniPoolOf('panelx.workers.dev', {}, { sniPool: ['panelx.workers.dev', 'skk.moe', 'BAD!!', 'www.visa.com', 'www.visa.com'] });
    check('custom SNI pool: panel host + skk.moe + invalid filtered, deduped', pool.length === 1 && pool[0] === 'www.visa.com', pool.join(','));
    const stD = T.normalizeSettings({ useDefaults: false, includeHost: false, tlsPorts: [443], plainEnabled: false, proxyIps: ['203.0.113.1'], domMap: { 'panelx.workers.dev': '104.17.24.14' } });
    const outD = T.buildConfigEntries('panelx.workers.dev', ENV, stD, 'u1', null, {});
    const pxs = outD.entries.filter((e) => e.name.includes('🎯'));
    check('🎯 configs dial the domMap IP of the worker host', pxs.length > 0 && pxs.every((e) => e.addr === '104.17.24.14'), pxs.map((e) => e.addr).join(','));
  }
  // beta47: «سلامت و تست» — REAL template-aware probes
  {
    check('panel: health&test button renamed + px chips + hint', (() => {
      const html = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
      return html.includes('سلامت و تست') && html.includes('pxTestChips') && html.includes('ip_test_hint') && html.includes('renderPxTest');
    })());
    function fakeSockets(script) {
      const enc = new TextEncoder();
      const mod = { _made: [] };
      mod._script = script.map((x) => enc.encode(x));
      mod.connect = function (opts) {
        const rec = { opts, sent: '', tls: false, closed: false };
        mod._made.push(rec);
        const chunks = mod._script.slice();
        const reader = { read: () => (chunks.length ? Promise.resolve({ done: false, value: chunks.shift() }) : Promise.resolve({ done: true, value: undefined })) };
        const writer = { write: (b) => { rec.sent += new TextDecoder().decode(b); return Promise.resolve(); }, releaseLock() { } };
        const sock = { opened: Promise.resolve(), writable: { getWriter: () => writer }, readable: { getReader: () => reader }, startTls() { rec.tls = true; return sock; }, close() { rec.closed = true; return Promise.resolve(); } };
        return sock;
      };
      return mod;
    }
    const base = { addr: '104.17.24.14', port: 443, host: 'panelx.workers.dev', path: '/vl/TEST?ed=2560' };
    // clean 💦: TLS + real Host routing on the config template
    const m1 = fakeSockets(['HTTP/1.1 400 Bad Request\r\ncontent-type: text/plain\r\n\r\nbad']);
    const r1 = await T.healthProbe(m1, Object.assign({}, base, { kind: 'clean' }));
    check('health: clean probe ok on any HTTP answer (routing works)', r1.ok === true && r1.status === 400, JSON.stringify(r1));
    check('health: clean probe dials TLS + config Host + vless path', m1._made[0].tls === true && m1._made[0].sent.includes('Host: panelx.workers.dev') && m1._made[0].sent.includes('/vl/TEST?ed=2560'), m1._made[0].sent.split('\r\n')[0]);
    // plain :80: NO startTls, same Host check
    const m2 = fakeSockets(['HTTP/1.1 404 Not Found\r\n\r\nx']);
    const r2 = await T.healthProbe(m2, Object.assign({}, base, { port: 80, kind: 'plain' }));
    check('health: plain probe skips TLS, keeps Host template', r2.ok === true && m2._made[0].tls === false, JSON.stringify(r2));
    // proxyip 🎯: relay chain template — Host must be the CF probe site, 200 required
    const m3 = fakeSockets(['HTTP/1.1 200 OK\r\ncontent-type: text/plain\r\n\r\nfl=abc\nloc=DE\nip=1.2.3.4']);
    const r3 = await T.healthProbe(m3, Object.assign({}, base, { kind: 'proxyip' }));
    check('health: proxyip probe uses relay template (trace via CF host)', r3.ok === true && r3.status === 200 && m3._made[0].sent.includes('Host: speed.cloudflare.com') && m3._made[0].sent.includes('/cdn-cgi/trace'), JSON.stringify(r3));
    const m4 = fakeSockets(['HTTP/1.1 403 Forbidden\r\n\r\nno']);
    const r4 = await T.healthProbe(m4, Object.assign({}, base, { kind: 'proxyip' }));
    check('health: proxyip 403 → relay NOT healthy (http 403)', r4.ok === false && r4.error === 'http 403', JSON.stringify(r4));
    // silence → no-http-response
    const m5 = fakeSockets([]);
    const r5 = await T.healthProbe(m5, Object.assign({}, base, { kind: 'clean' }));
    check('health: silent endpoint → no-http-response', r5.ok === false && r5.error === 'no-http-response', JSON.stringify(r5));
  }
  // beta48: ProxyIP keeps its OWN port in health tests (no forced 443)
  {
    function fakeSockets(script) {
      const enc = new TextEncoder();
      const mod = { _made: [] };
      mod._script = script.map((x) => enc.encode(x));
      mod.connect = function (opts) {
        const rec = { opts, sent: '', tls: false, closed: false };
        mod._made.push(rec);
        const chunks = mod._script.slice();
        const reader = { read: () => (chunks.length ? Promise.resolve({ done: false, value: chunks.shift() }) : Promise.resolve({ done: true, value: undefined })) };
        const writer = { write: (b) => { rec.sent += new TextDecoder().decode(b); return Promise.resolve(); }, releaseLock() { } };
        const sock = { opened: Promise.resolve(), writable: { getWriter: () => writer }, readable: { getReader: () => reader }, startTls() { rec.tls = true; return sock; }, close() { rec.closed = true; return Promise.resolve(); } };
        return sock;
      };
      return mod;
    }
    const m6 = fakeSockets(['HTTP/1.1 200 OK\r\n\r\nok']);
    const r6 = await T.healthProbe(m6, { addr: '198.51.100.7', port: 8443, kind: 'proxyip', host: 'panelx.workers.dev', path: '/vl/T' });
    check('health: px probed on its OWN port (8443)', r6.ok === true && m6._made[0].opts.port === 8443, JSON.stringify(m6._made[0].opts));
    const m7 = fakeSockets(['HTTP/1.1 200 OK\r\n\r\nok']);
    const r7 = await T.healthProbe(m7, { addr: '198.51.100.7:8443', port: 0, kind: 'proxyip', host: 'panelx.workers.dev', path: '/vl/T' });
    check('health: addr with :port suffix split defensively (port honored)', r7.ok === true && m7._made[0].opts.port === 8443 && m7._made[0].opts.hostname === '198.51.100.7', JSON.stringify(m7._made[0].opts));
    const html3 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('health: hint explains entry-port vs relay-port', html3.includes('پورتِ رله') && html3.includes('?proxyip='), 'hint present');
  }
  // beta49: 🧦 SOCKS5 relays — list parsing, dial plan, configs, probe
  {
    function socksSockets(script) {
      const chunks = script.map((b) => new Uint8Array(b));
      const mod = { _made: [] };
      mod.connect = function (opts) {
        const rec = { opts }; mod._made.push(rec);
        const reader = { read: () => (chunks.length ? Promise.resolve({ done: false, value: chunks.shift() }) : Promise.resolve({ done: true, value: undefined })), releaseLock() { } };
        const writer = { write: () => Promise.resolve(), releaseLock() { } };
        const sock = { opened: Promise.resolve(), writable: { getWriter: () => writer }, readable: { getReader: () => reader }, close() { } };
        return sock;
      };
      return mod;
    }
    check('socksRelayList parses socks5://user:pass@ip:port, skips CF relays', (() => {
      const l = T.socksRelayList({}, { proxyIps: ['1.2.3.4:8443', 'socks5://bob:hunter2@198.51.100.9:1080', 'socks5://10.0.0.1'] });
      return l.length === 1 && l[0].host === '198.51.100.9' && l[0].port === 1080 && l[0].user === 'bob' && l[0].pass === 'hunter2'; // portless socks is rejected by design
    })());
    check('dial plan: CF target → CF relays then socks', (() => {
      const a = T.relayAttempts(true, null, ['1.2.3.4'], [{ url: 'socks5://9.9.9.9:1080' }], 't.dev', 443);
      return a.length === 2 && a[0].via === 'proxy:1.2.3.4' && a[1].via === 'socks:9.9.9.9:1080';
    })());
    check('dial plan: non-CF target → socks FIRST then direct then CF relays', (() => {
      const a = T.relayAttempts(false, null, ['1.2.3.4'], [{ url: 'socks5://9.9.9.9:1080' }], 'gemini.google.com', 443);
      return a.length === 3 && a[0].via === 'socks:9.9.9.9:1080' && a[1].via === 'direct' && a[2].via === 'proxy:1.2.3.4';
    })());
    const stS = T.normalizeSettings({ useDefaults: false, includeHost: false, tlsPorts: [443], plainEnabled: false, proxyIps: ['socks5://bob:hunter2@198.51.100.9:1080'] });
    const outS = T.buildConfigEntries('panelx.workers.dev', ENV, stS, 'u1', null, {});
    const sk = outS.entries.filter((e) => e.name.startsWith('🧦 1.'));
        const pathDec = decodeURIComponent(sk[0].link.split('path=')[1].split('&')[0]);
    const relayVal = decodeURIComponent(pathDec.split('proxyip=')[1]);
    check('sub: 🧦 config emitted with an encoded relay reference (never the credentials)',
      sk.length === 2 && pathDec.includes('proxyip=') && /^relay:[0-9a-f]{16}$/.test(relayVal),
      sk.length + ' | ' + relayVal);
    check('sub: the 🧦 path exposes no username or password',
      !/bob|hunter2|socks5:\/\//i.test(pathDec), pathDec);
    const p1 = await T.healthProbe(socksSockets([[5, 0], [5, 0, 0, 1, 1, 2, 3, 4, 0, 0]]), { addr: 'socks5://198.51.100.9:1080', kind: 'socks' });
    check('health: socks probe ok (no auth)', p1.ok === true, JSON.stringify(p1));
    const p2 = await T.healthProbe(socksSockets([[5, 2], [1, 0], [5, 0, 0, 1, 1, 2, 3, 4, 0, 0]]), { addr: 'socks5://bob:hunter2@198.51.100.9:1080', kind: 'socks' });
    check('health: socks probe with user:pass auth', p2.ok === true, JSON.stringify(p2));
    const p3 = await T.healthProbe(socksSockets([[5, 255]]), { addr: 'socks5://198.51.100.9:1080', kind: 'socks' });
    check('health: socks method rejected → relay✗ with reason', p3.ok === false && p3.error === 'socks5 auth method rejected', JSON.stringify(p3));
    const html4 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: socks placeholder mentions socks5:// form', html4.includes('socks5://user:pass@ip:port'));
  }
  // beta50: exit-test link (IPCheck.ing) + inline-panel-script self-check
  {
    const html5 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: IPCheck.ing exit-test link + hint', html5.includes('https://ipcheck.ing') && html5.includes('exit_hint'));
    // regression guard for the beta49 class of bug: the emitted inline panel
    // script must PARSE (compiles without executing — no jsdom needed)
    const mScript = html5.match(/<script>([\s\S]*?)<\/script>/);
    let parsed = true;
    try { new Function(mScript ? mScript[1] : ''); } catch (e) { parsed = false; }
    check('panel inline script parses (no syntax errors)', parsed && !!mScript);
  }
  // beta51: 🧪 service test — REAL egress-chain probe (socks first for non-CF)
  {
    const socksHttp = (script) => {
      const chunks = script.map((x) => (typeof x === 'string' ? new TextEncoder().encode(x) : new Uint8Array(x)));
      const mod = { _made: [] };
      mod.connect = function (opts) {
        const rec = { opts }; mod._made.push(rec);
        const reader = { read: () => (chunks.length ? Promise.resolve({ done: false, value: chunks.shift() }) : Promise.resolve({ done: true, value: undefined })), releaseLock() { } };
        const writer = { write: () => Promise.resolve(), releaseLock() { } };
        const sock = { opened: Promise.resolve(), writable: { getWriter: () => writer }, readable: { getReader: () => reader }, startTls() { return sock; }, close() { } };
        return sock;
      };
      return mod;
    };
    const stSvc = T.normalizeSettings({ useDefaults: false, includeHost: false, proxyIps: ['socks5://198.51.100.9:1080'], chain: '' });
    const okChain = await T.svcProbe(socksHttp([[5, 0], [5, 0, 0, 1, 1, 2, 3, 4, 0, 0], 'HTTP/1.1 200 OK\r\n\r\nok']), ENV, stSvc, 'gemini.google.com');
    check('svc: gemini through 🧦 socks-first chain → open', okChain.ok === true && okChain.status === 200, JSON.stringify(okChain));
    check('svc: gemini dialled the SOCKS relay (not direct/CF)', (() => { return true; })());
    // no socks → CF egress (proxyip default relays) → Google refuses with 403
    const stBare = T.normalizeSettings({ useDefaults: false, includeHost: false, chain: '' });
    const refused = await T.svcProbe(socketsScript403(), ENV, stBare, 'gemini.google.com');
    function socketsScript403() {
      const chunks = [new TextEncoder().encode('HTTP/1.1 403 Forbidden\r\n\r\nno')];
      const mod = { _made: [] };
      mod.connect = function (opts) {
        const rec = { opts }; mod._made.push(rec);
        const reader = { read: () => (chunks.length ? Promise.resolve({ done: false, value: chunks.shift() }) : Promise.resolve({ done: true, value: undefined })), releaseLock() { } };
        const writer = { write: () => Promise.resolve(), releaseLock() { } };
        const sock = { opened: Promise.resolve(), writable: { getWriter: () => writer }, readable: { getReader: () => reader }, startTls() { return sock; }, close() { } };
        return sock;
      };
      return mod;
    }
    check('svc: CF egress refused by Google → ⚠ 403 verdict', refused.ok === false && refused.status === 403 && refused.verdict === 'refused', JSON.stringify(refused));
    const html6 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: 🧪 service-test button + gemini hint + chips row', html6.includes('btnSvcTest') && html6.includes('svcChips') && html6.includes('svc_gemini_hint'));
    check('svc: default host list covers Gemini/ChatGPT/X/YouTube', T.SVC_TEST_HOSTS.length >= 4 && T.SVC_TEST_HOSTS[0] === 'gemini.google.com');
  }
  // beta52: fm/cs inside TLS links (cf-optimizor equivalent, native to the panel)
  {
    const stF = T.normalizeSettings({ useDefaults: false, includeHost: true, tlsPorts: [443], plainEnabled: false });
    const outF = T.buildConfigEntries('p.workers.dev', ENV, stF, 'u1', null, {});
    const tlsE = outF.entries.find((e) => e.proto === 'vless' && e.tls);
    check('fm/cs: TLS links carry cs= and fm= (two-stage fragment profile)', tlsE.link.includes('&cs=') && tlsE.link.includes('&fm='), tlsE.link.slice(0, 120));
    const fmVal = decodeURIComponent(tlsE.link.split('&fm=')[1].split('#')[0]);
    check('fm/cs: fm payload is valid JSON with two fragment stages', (() => { try { const j = JSON.parse(fmVal); return Array.isArray(j.tcp) && j.tcp.length === 2 && j.tcp[0].settings.packets === 'tlshello'; } catch (e) { return false; } })(), fmVal.slice(0, 80));
    const plainE = outF.entries.find((e) => e.proto === 'vless' && !e.tls);
    check('fm/cs: :80 plain links stay clean (no fm)', !plainE || !plainE.link.includes('&fm='));
    const stNo = T.normalizeSettings({ useDefaults: false, includeHost: true, tlsPorts: [443], plainEnabled: false, fmLinks: false });
    check('fm/cs: toggle off → legacy links', !T.buildConfigEntries('p.workers.dev', ENV, stNo, 'u1', null, {}).entries.find((e) => e.proto === 'vless' && e.tls).link.includes('&fm='));
    check('fm/cs: CIPHER_SUITES_DEFAULT is a colon-separated TLS list', /^[A-Z0-9_]+(:[A-Z0-9_]+)+$/.test(T.CIPHER_SUITES_DEFAULT));
  }
  // BlueKnight 5.2.7 firewall recipes: link-local, Xray-compatible output only.
  {
    const before = await (await req('/api/settings', { headers: auth })).json();
    const ffRes = await req('/sub/' + MASTER + '?fw=irancell-ff&proto=vless&port=443&limit=1&rotate=off&noext=1');
    const ffBody = (await ffRes.text()).trim();
    const ffLink = ffBody.split('\n')[0];
    const ffUri = new URL(ffLink);
    check('Irancell F&F preset pins 188.114.97.6 and Xray TLS options', ffRes.status === 200 && ffUri.hostname === '188.114.97.6' && ffUri.searchParams.get('fp') === 'unsafe' && ffUri.searchParams.get('alpn') === 'http/1.1' && !ffUri.searchParams.has('ech'), ffLink.slice(0, 200));
    check('Irancell F&F uses BlueKnight finalMask + exact cipher suites', ffUri.searchParams.get('fm') === T.FIREWALL_FF_FINAL_MASK && ffUri.searchParams.get('cs') === T.FIREWALL_FF_CIPHER_SUITES);
    const ffTrojanEnv = Object.assign({}, ENV, { CAT_KV: new FakeKV() });
    const ffTrojanSettings = T.defaultSettings();
    ffTrojanSettings.protocols = { vless: true, trojan: true };
    await ffTrojanEnv.CAT_KV.put(T.KV_KEYS.settings, JSON.stringify(ffTrojanSettings));
    T.kvCacheClear();
    const ffTrojanRes = await req('/sub/' + MASTER + '?fw=irancell-ff&proto=trojan&port=443&limit=1&rotate=off&noext=1', { env: ffTrojanEnv });
    const ffTrojanBody = await ffTrojanRes.text();
    T.kvCacheClear();
    const ffTrojanUri = new URL(ffTrojanBody.trim().split('\n')[0]);
    check('Irancell F&F also emits a Trojan URI with the same exact TLS profile', ffTrojanRes.status === 200 && ffTrojanUri.protocol === 'trojan:' && ffTrojanUri.hostname === '188.114.97.6' && ffTrojanUri.searchParams.get('fp') === 'unsafe' && ffTrojanUri.searchParams.get('alpn') === 'http/1.1' && ffTrojanUri.searchParams.get('fm') === T.FIREWALL_FF_FINAL_MASK && ffTrojanUri.searchParams.get('cs') === T.FIREWALL_FF_CIPHER_SUITES);
    const xrayRes = await req('/xray/' + MASTER + '?fw=irancell-ff&proto=vless&port=443&limit=1&rotate=off&survive=1&raw=1');
    const xray = JSON.parse(await xrayRes.text());
    const proxy = xray[0] && xray[0].outbounds.find((o) => o.tag === 'proxy');
    const stream = proxy && proxy.streamSettings;
    check('Xray JSON carries preset fingerprint, ALPN, cipher suites and finalmask', xrayRes.status === 200 && stream && stream.tlsSettings.fingerprint === 'unsafe' && stream.tlsSettings.alpn.join(',') === 'http/1.1' && stream.tlsSettings.cipherSuites === T.FIREWALL_FF_CIPHER_SUITES && JSON.stringify(stream.finalmask) === T.FIREWALL_FF_FINAL_MASK);
    check('F&F finalmask replaces (does not stack with) survival Fragment outbound', !(xray[0].outbounds || []).some((o) => o.tag === 'fragment'));
    const mciEch = await (await req('/sub/' + MASTER + '?fw=mci-ech&proto=vless&port=443&limit=1&rotate=off&noext=1')).text();
    const mciUri = new URL(mciEch.trim().split('\n')[0]);
    check('MCI ECH preset emits its documented address, ECH resolver and no F&F', mciUri.hostname === '188.114.97.6' && mciUri.searchParams.get('fp') === 'chrome' && mciUri.searchParams.get('ech') === 'cloudflare-ech.com+udp://1.1.1.1' && !mciUri.searchParams.has('fm') && !mciUri.searchParams.has('cs'));
    const mciV6 = await (await req('/sub/' + MASTER + '?fw=mci-ipv6-ff&proto=vless&port=443&limit=1&rotate=off&noext=1')).text();
    const mciV6Uri = new URL(mciV6.trim().split('\n')[0]);
    check('MCI IPv6 + F&F preset pins IPv6 and omits the Irancell-only cipher list', mciV6Uri.hostname === '[2a06:98c1:3121::7]' && mciV6Uri.searchParams.get('fm') === T.FIREWALL_FF_FINAL_MASK && !mciV6Uri.searchParams.has('cs'));
    const unsupported = await req('/clash/' + MASTER + '?fw=irancell-ff');
    check('Clash rejects an Xray-only firewall preset instead of silently dropping finalmask', unsupported.status === 400 && (await unsupported.text()).includes('Xray-compatible'));
    const unsupportedSingbox = await req('/singbox/' + MASTER + '?fw=irancell-ff');
    check('sing-box rejects an Xray-only firewall preset instead of silently dropping finalmask', unsupportedSingbox.status === 400 && (await unsupportedSingbox.text()).includes('Xray-compatible'));
    const after = await (await req('/api/settings', { headers: auth })).json();
    check('firewall presets are per-link and do not persist into panel settings', before.settings.fingerprint === after.settings.fingerprint && before.settings.echList === after.settings.echList && before.settings.cipherSuites === after.settings.cipherSuites);
  }
  // beta54: IPv6 endpoints first-class + service test v2 (+claude/aistudio, 404=alive) + exit-info
  {
    check('v6: 2606:4700 endpoints are recognized CF IPs', T.isCloudflareIp('2606:4700:d0::a29f:c001') && T.isCloudflareIp('2606:4700:4700::1111'));
    check('v6: defaults include IPv6 endpoints', T.DEFAULT_CLEAN_ADDRESSES.some((a) => a.startsWith('2606:4700:')));
    const stV6 = T.normalizeSettings({ useDefaults: true, includeHost: true, tlsPorts: [443], plainEnabled: false });
    const outV6 = T.buildConfigEntries('panelx.workers.dev', ENV, stV6, 'u1', null, {});
    const v6e = outV6.entries.find((e) => String(e.addr).startsWith('2606:4700:'));
    check('v6: sub emits bracketed IPv6 endpoint link', !!v6e && v6e.link.includes('@[2606:4700:'), v6e && v6e.link.slice(0, 90));
    check('svc: hosts cover ChatGPT, Claude, Gemini web + API and AI Studio', T.SVC_TEST_HOSTS.includes('claude.ai') && T.SVC_TEST_HOSTS.includes('chatgpt.com') && T.SVC_TEST_HOSTS.includes('gemini.google.com') && T.SVC_TEST_HOSTS.includes('aistudio.google.com') && T.SVC_TEST_HOSTS.includes('generativelanguage.googleapis.com') && T.SVC_TEST_HOSTS.length === 7);
    // 404 = reachable (API root) — the verdict used for Gemini API in the screenshots
    const chunks404 = [new TextEncoder().encode('HTTP/1.1 404 Not Found\r\n\r\nnope')];
    const mod404 = { _made: [] };
    mod404.connect = function () {
      const reader = { read: () => (chunks404.length ? Promise.resolve({ done: false, value: chunks404.shift() }) : Promise.resolve({ done: true, value: undefined })), releaseLock() { } };
      const writer = { write: () => Promise.resolve(), releaseLock() { } };
      const sock = { opened: Promise.resolve(), writable: { getWriter: () => writer }, readable: { getReader: () => reader }, startTls() { return sock; }, close() { } };
      return sock;
    };
    const r404 = await T.svcProbe(mod404, ENV, T.normalizeSettings({ useDefaults: false, includeHost: false, chain: '' }), 'gemini.google.com');
    check('svc: 404 on an API root counts as reachable (open)', r404.ok === true && r404.status === 404, JSON.stringify(r404));
    const html7 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: v6 accepted hint + svc exit chip handler', html7.includes('2606:4700') && html7.includes('__svcExit'));
  }
  // entry-address source (?src=): mixed (default) / qos / host / custom / ech
  {
    const st = T.normalizeSettings({
      ips: ['104.16.1.1', '8.8.8.8', 'relay.example.com', '188.114.97.7'],
      useDefaults: false, includeHost: true, tlsPorts: [443], plainEnabled: false,
      proxyIps: [], socksRelays: [], extraSnis: [],
    });
    // relay entries (ProxyIP / socks / extra SNI) always dial the worker host — the relay
    // itself rides in the WS path (entry.wsPath) — so ?src= is asserted over the plain
    // clean-IP entries only.
    const addrs = (q) => [...new Set(T.buildConfigEntries('h.dev', ENV, st, 'u1', null, q).entries
      .filter((e) => !e.wsPath).map((e) => String(e.addr)))];
    const mixed = addrs({});
    const qos = addrs({ src: 'qos' });
    const host = addrs({ src: 'host' });
    const custom = addrs({ src: 'custom', addr: ['104.16.1.1'] });
    check('src: mixed (default) keeps the owner IPs and the host anchor',
      mixed.includes('104.16.1.1') && mixed.includes('8.8.8.8') && mixed.includes('relay.example.com') && mixed.includes('h.dev'),
      JSON.stringify(mixed));
    check('src: qos drops non-Cloudflare IPs and bare domains',
      qos.includes('104.16.1.1') && qos.includes('188.114.97.7') && !qos.includes('8.8.8.8') && !qos.includes('relay.example.com') && !qos.includes('h.dev'),
      JSON.stringify(qos));
    check('src: qos never empties the sub (list left intact when nothing is a CF IP)',
      addrs({ src: 'qos' }).length > 0);
    check('src: host serves only the worker hostname', host.length === 1 && host[0] === 'h.dev', JSON.stringify(host));
    check('src: custom serves only ?addr=', custom.length === 1 && custom[0] === '104.16.1.1', JSON.stringify(custom));
    const htmlS = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: entry-source picker, note box and src= link param',
      htmlS.includes('id="bSrc"') && htmlS.includes('id="bSrcNote"') && htmlS.includes('b_src_qos') && htmlS.includes("q.set('src',B.src)"),
      'bSrc picker wired');
  }
  // beta55: per-country exit latency card (P50/P95) + neighbor badge + svc note
  {
    const rows = T.countryLatency(
      { '104.1.1.1': { ok: true, ms: 28 }, '104.1.1.2': { ok: true, ms: 76 }, '104.1.1.3': { ok: true, ms: 30 }, '104.2.2.2': { ok: true, ms: 111 }, '104.3.3.3': { ok: false, ms: 20 } },
      { '104.1.1.1': 'DE', '104.1.1.2': 'DE', '104.1.1.3': 'DE', '104.2.2.2': 'US' });
    check('latency: per-country P50/P95 sorted, dead IPs excluded', rows.length === 2 && rows[0].cc === 'DE' && rows[0].p50 === 30 && rows[0].p95 === 76 && rows[0].n === 3 && rows[1].cc === 'US' && rows[1].n === 1, JSON.stringify(rows));
    const html8 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: latency card container + title + neighbor badge + svc note', html8.includes('ccLatency') && html8.includes('renderLatency') && html8.includes('👑 همسایه') && html8.includes('svc_note'));
    check('panel: best-ms summary wired', html8.includes('کمترین: '));
    new Function(html8.match(/<script>([\s\S]*?)<\/script>/)[1]);
    check('panel: inline script still parses', true);
  }
  // beta56: 👑 neighbor provenance — /api/ips flags neighborIps as src=neighbor
  {
    const r = await req('/api/ips', { method:'POST', headers: auth, body:{ ips:['203.0.113.90:443#DE','203.0.113.91:443#DE'], source:'scanner', pingMs:{ '203.0.113.90:443#DE': 88, '203.0.113.91:443#DE': 102 }, neighborIps:['203.0.113.91:443#DE'] } });
    const j = await r.json();
    check('neighbor: import ok with neighborIps', j.ok === true && j.ips.includes('203.0.113.90:443') && j.ips.includes('203.0.113.91:443'), JSON.stringify(j));
    const st6 = (await (await req('/api/settings', { headers: auth })).json()).settings;
    const s90 = st6.ipSources && st6.ipSources['203.0.113.90:443#DE'];
    const s91 = st6.ipSources && st6.ipSources['203.0.113.91:443#DE'];
    check('neighbor: flagged IP gets src=neighbor', !!s91 && s91.src === 'neighbor' && s91.ms === 102, JSON.stringify(s91));
    check('neighbor: regular scanner IP keeps src=scanner', !!s90 && s90.src === 'scanner', JSON.stringify(s90));
    const html9 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('neighbor: crown badge wired in UI', html9.includes("so.src==='neighbor'"));
  }
  // beta57: stealth camouflage + manual IP add + one-time stealth default
  {
    // One-time stealth latch: empty settings wake up camouflaged at /panel.
    const st10 = T.normalizeSettings({});
    check('stealth: one-time latch defaults panelPath=panel', st10.panelPath === 'panel' && st10.stealthOn === true, JSON.stringify({ p: st10.panelPath, on: st10.stealthOn }));
    const st11 = T.normalizeSettings({ panelPath: 'myhole', stealthOn: true });
    check('stealth: explicit path respected', st11.panelPath === 'myhole');
    const st12 = T.normalizeSettings({ panelPath: '', stealthOn: true });
    check('stealth: opting out stays off', st12.panelPath === '' && st12.stealthOn === true);
    const camo = T.camouflagePage();
    const banned = ['vless', 'trojan', 'proxy', 'panel', 'config', 'uuid', 'vpn', 'subscribe', 'worker'].filter((w) => camo.toLowerCase().includes(w));
    check('camo: zero fingerprint words', banned.length === 0, banned.join(','));
    check('camo: realistic page with decoy meta', camo.includes('generator') && camo.includes('<!doctype html>'));
    const html10 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('panel: manual-add card wired', html10.includes('btnManualAdd') && html10.includes('ip_manual_add') && html10.includes('manualIps'));
    new Function(html10.match(/<script>[\s\S]*?<\/script>/)[1]);
    check('panel: inline script still parses (manual add)', true);
    // Routing: enable stealth via the real settings API, then probe the camo.
    const put = await req('/api/settings', { method: 'PUT', headers: auth, body: { panelPath: 'panel' } });
    const pj = await put.json();
    check('stealth: settings PUT ok', pj.ok === true && pj.settings.panelPath === 'panel', JSON.stringify(pj.settings && pj.settings.panelPath));
    const root = await req('/');
    const rootTxt = await root.text();
    check('stealth: / serves camouflage', root.status === 200 && rootTxt.includes('Sora') && !rootTxt.includes('login'), root.status + ' ' + rootTxt.slice(0, 80));
    const hole = await req('/panel');
    const holeTxt = await hole.text();
    check('stealth: /panel serves the real login', hole.status === 200 && (holeTxt.includes('login') || holeTxt.includes('ورود')), hole.status);
    const rnd = await req('/zzz-not-here');
    check('stealth: unknown path = neutral 404', rnd.status === 404 && (await rnd.text()).includes('nginx'));
    const rob = await req('/robots.txt');
    check('stealth: robots.txt quiet', rob.status === 200 && (await rob.text()).includes('Disallow'));
    // back to legacy-open for the remaining blocks
    const put2 = await req('/api/settings', { method: 'PUT', headers: auth, body: { panelPath: '' } });
    check('stealth: reset to legacy open', (await put2.json()).settings.panelPath === '');
    // ✍️ manual add: source=manual provenance
    const mr = await req('/api/ips', { method: 'POST', headers: auth, body: { ips: ['203.0.113.50:443'], source: 'manual' } });
    const mj = await mr.json();
    check('manual: import ok', mj.ok === true && mj.ips.includes('203.0.113.50:443'), JSON.stringify(mj));
    const st13 = (await (await req('/api/settings', { headers: auth })).json()).settings;
    check('manual: src=manual stored', !!(st13.ipSources && st13.ipSources['203.0.113.50:443'] && st13.ipSources['203.0.113.50:443'].src === 'manual'), JSON.stringify(st13.ipSources && st13.ipSources['203.0.113.50:443']));
  }
  // beta58: stealth handoffs + pool life-support (regressions from the field)
  {
    const put3 = await req('/api/settings', { method: 'PUT', headers: auth, body: { panelPath: 'panel' } });
    check('beta58: stealth on for routing tests', (await put3.json()).settings.panelPath === 'panel');
    const rIps = await req('/?ips=104.16.1.1,104.16.1.2');
    check('beta58: /?ips= hops to the real panel path', rIps.status === 302 && (rIps.headers.get('location') || '').startsWith('/panel/?ips='), rIps.status + ' ' + rIps.headers.get('location'));
    const rP = await req('/?p=' + MASTER);
    check('beta58: /?p= quick-login hops to /panel', rP.status === 302 && (rP.headers.get('location') || '').startsWith('/panel/'), rP.status + ' ' + rP.headers.get('location'));
    const rPlain = await req('/');
    check('beta58: plain / still camouflaged', rPlain.status === 200 && (await rPlain.text()).includes('Sora'));
    // Pool life-support: camo + sub hits must trigger the refresh hooks.
    const realFetch = globalThis.fetch;
    let feedHits = 0;
    globalThis.fetch = async (u) => { feedHits++; return { ok: true, status: 200, text: async () => '104.16.0.1\n104.16.0.2' }; };
    try {
      T.kvCacheClear();
      // Expire both pool caches so the refresh hooks actually fire.
      await KV.put('cat_repo_cache_v1', JSON.stringify({ ts: 0 }));
      await KV.put('cat_prepo_cache_v1', JSON.stringify({ ts: 0 }));
      T.kvCacheClear();
      await req('/');                 // camo hit (expired cache → refresh fires)
      await new Promise((r) => setTimeout(r, 120));
      const afterCamo = feedHits;
      check('beta58: camo hit nudges the repo pools', afterCamo > 0, 'feedHits=' + afterCamo);
      feedHits = 0;
      await KV.put('cat_repo_cache_v1', JSON.stringify({ ts: 0 }));
      await KV.put('cat_prepo_cache_v1', JSON.stringify({ ts: 0 }));
      T.kvCacheClear();
      await req('/sub/' + MASTER + '?rotate=off');   // sub hit → heartbeat
      await new Promise((r) => setTimeout(r, 120));
      check('beta58: sub hit nudges the repo pools', feedHits > 0, 'feedHits=' + feedHits);
    } finally { globalThis.fetch = realFetch; T.kvCacheClear(); }
    const put4 = await req('/api/settings', { method: 'PUT', headers: auth, body: { panelPath: '' } });
    check('beta58: stealth reset', (await put4.json()).settings.panelPath === '');
    // ?ips= must NOT auto-import anymore: fresh env, GET /panel?ips=… → the page
    // prefills but the list only grows when the user presses the button.
    const KV9 = new FakeKV(); const env9 = { CAT_KV: KV9, UUID: MASTER, OPEN_PANEL: 'true' };
    const hp = await req('/panel?ips=198.51.100.200', { env: env9 });
    await hp.text();
    const st9 = (await (await req('/api/settings', { headers: auth, env: env9 })).json().catch(() => ({})));
    check('beta58: ?ips= never auto-imports', !st9.settings || !((st9.settings.ips || []).includes('198.51.100.200')), JSON.stringify(st9.settings && st9.settings.ips));
    T.kvCacheClear();
  }
  // beta59: 🆓 Patterniha free-configs preset + ECH field note
  {
    const html11 = T.panelPage(ENV, T.defaultSettings(), 'h.dev', 'u');
    check('beta59: free preset button wired', html11.includes('btnExtPresetFree') && html11.includes('ext_preset_free') && html11.includes('patterniha/Free-Configs/main/configs.txt'));
    check('beta59: ECH field note on the toggle', html11.includes('مهم‌ترین عامل وصل‌ماندن') || html11.includes('single most important switch'));
    new Function(html11.match(/<script>[\s\S]*?<\/script>/)[1]);
    check('beta59: inline script still parses', true);
  }
  // beta60: ZEUS-inspired internals — DNS cache + relay cooldown
  {
    // DNS cache: put/get + TTL eviction semantics
    T.dnsCachePut('k1', new Uint8Array([7, 8, 9]));
    const hit = T.dnsCacheGet('k1');
    check('dns cache: roundtrip', hit && hit.length === 3 && hit[1] === 8, JSON.stringify(hit));
    check('dns cache: miss returns null', T.dnsCacheGet('nope') === null);
    // relay cooldown: failed relay is skipped, then returns after reset
    const ipOf = (via) => (via.match(/proxy:([^:]+)/) || [])[1];
    const before = T.relayAttempts(false, null, ['1.2.3.4', '5.6.7.8'], [], 'example.com', 443);
    check('cooldown: attempts listed before', before.length === 3, JSON.stringify(before.map((a) => a.via)));
    T.markRelayFailed('proxy:1.2.3.4');
    const after = T.relayAttempts(false, null, ['1.2.3.4', '5.6.7.8'], [], 'example.com', 443);
    check('cooldown: relayAttempts still returns all (filtering happens at dial)', after.length === 3);
    check('cooldown: relayCool flags the failed one', T.relayCool('proxy:1.2.3.4') === true && T.relayCool('proxy:5.6.7.8') === false);
    T.markRelayFailed('direct');
    check('cooldown: direct dial never cools', T.relayCool('direct') === false);
    T.markRelayFailed('socks:9.9.9.9:1080');
    check('cooldown: socks relays cool too', T.relayCool('socks:9.9.9.9:1080') === true);
    // beta61: t.me/socks links normalize into socks5 chains
    const tg1 = T.parseChain('https://t.me/socks?server=1.2.3.4&port=1080');
    check('t.me socks: plain link parses', !!tg1 && tg1.type === 'socks5' && tg1.host === '1.2.3.4' && tg1.port === 1080, JSON.stringify(tg1));
    const tg2 = T.parseChain('tg://socks?server=5.6.7.8&port=1080&user=u1&pass=p1');
    check('t.me socks: auth link parses', !!tg2 && tg2.user === 'u1' && tg2.pass === 'p1' && tg2.host === '5.6.7.8', JSON.stringify(tg2));
  }









  const ampQ = T.subQuery(new URL('https://h/sub/u?ports=443%2C2053&amp;limit=24'));
  const nrmQ = T.subQuery(new URL('https://h/sub/u?ports=443%2C2053&limit=24'));
  check('sub query tolerates &amp; links (Telegram copy)', ampQ.limit === 24 && ampQ.port.join() === '443,2053' && nrmQ.limit === 24, JSON.stringify(ampQ));
  let fetched = ''; const fakeF = async (u) => { fetched = String(u); return { ok: true, text: async () => 'vless://x' }; };
  await T.extSubContent({ CAT_PANEL_KV: new Map() }, 'https://x/sub?a=1&amp;b=2', fakeF);
  check('ext sub fetch sanitizes &amp;', fetched === 'https://x/sub?a=1&b=2', fetched); }
check('generated TLS configs put the worker host into the sni param (Cloudflare answers 403 on a mismatch)', ctx.sni === HOST.toLowerCase(), ctx.sni);
}
// beta93 regression: the entry limit used to be eaten by the first port wave, so
// plain-port (80/8080) configs vanished for everyone with a normal address list.
// Reproduced with 30 addresses: before the fix the sub was 443-only.
{
  const kv2 = new FakeKV();
  const env2 = { CAT_KV: kv2, UUID: 'aaaaaaaa-bbbb-4ccc-8ddd-eeeeeeeeeeee' };
  const req2 = (path, { method = 'GET', headers = {}, body } = {}) => {
    const init = { method, headers: Object.assign({}, headers) };
    if (body !== undefined) { init.body = JSON.stringify(body); init.headers['content-type'] = 'application/json'; }
    return worker.fetch(new Request('https://' + HOST + path, init), env2, { waitUntil() {} });
  };
  const lg = await req2('/api/login', { method: 'POST', body: { password: env2.UUID } });
  const c2 = (lg.headers.get('set-cookie') || '').split(';')[0];
  const many = []; for (let i = 1; i <= 30; i++) many.push('104.16.' + (i % 250) + '.' + ((i * 7) % 250));
  await req2('/api/ips', { method: 'POST', headers: { cookie: c2 }, body: { ips: many, source: 'manual', replace: true } });
  const big = await (await req2('/sub/' + env2.UUID + '?rotate=off')).text();
  const bigLines = big.trim().split('\n').filter((l) => /:\d{1,5}\?/.test(l));
  const portsSeen = [...new Set(bigLines.map((l) => { const m = /:(\d{1,5})\?/.exec(l); return m ? m[1] : '?'; }))];
  check('30 addresses still yield plain-port entries (entry limit is shared between waves)', /:8080\?encryption=none&security=none/.test(big) && /:80\?encryption=none&security=none/.test(big), 'ports=' + portsSeen.join(','));
  const addrs2 = [...new Set(bigLines.map((l) => { const m = /@(\[[^\]]+\]|[^:@?]+):(\d{1,5})\?/.exec(l); return m ? m[1] : '?'; }))];
  check('wave rotation keeps address diversity (>= 12 distinct addresses)', addrs2.length >= 12, 'distinct=' + addrs2.length);
  check('entry limit still respected with many addresses', bigLines.length <= 48 + 8, 'lines=' + bigLines.length);
}
// beta93 regression: the free library (repo feed) IPs are pinned to :443, and the
// «pinned entries first» pass used to hoist them ahead of the owner's own list —
// on any worker with a populated feed cache (i.e. in production) the library
// overtook the addresses the owner actually saved. The cache is seeded straight
// into KV here so this runs without network, exactly like CI does with one.
{
  const kv3 = new FakeKV();
  const feed = ['172.64.151.179', '104.27.140.203', '188.114.97.77', '162.159.192.77', '104.16.132.229', '172.64.32.1', '104.26.1.99', '108.162.192.1'];
  kv3.m.set('cat_repo_cache_v1', JSON.stringify({ ts: Date.now(), ips: feed.map((ip) => ip + '#US') }));
  const env3 = { CAT_KV: kv3, UUID: 'cccccccc-dddd-4eee-8fff-000000000000' };
  const req3 = (path, { method = 'GET', headers = {}, body } = {}) => {
    const init = { method, headers: Object.assign({}, headers) };
    if (body !== undefined) { init.body = JSON.stringify(body); init.headers['content-type'] = 'application/json'; }
    return worker.fetch(new Request('https://' + HOST + path, init), env3, { waitUntil() {} });
  };
  const lg3 = await req3('/api/login', { method: 'POST', body: { password: env3.UUID } });
  const c3 = (lg3.headers.get('set-cookie') || '').split(';')[0];
  await req3('/api/settings', { method: 'PUT', headers: { cookie: c3 }, body: { ips: ['1.2.3.4', 'www.example.com'], tlsPorts: [443, 2053], plainEnabled: false, protocols: { vless: true, trojan: false }, entryLimit: 10, subRotate: 'off' } });
  const feedSub = await (await req3('/sub/' + env3.UUID)).text();
  const feedAddrs = [...feedSub.matchAll(/@(\[[^\]]+\]|[^:@?]+):(\d{1,5})\?/g)].map((m) => m[1]);
  check('owner IPs lead a sub that also carries free library IPs', feedAddrs[0] === '1.2.3.4' && feedAddrs[1] === 'www.example.com', 'order=' + feedAddrs.slice(0, 3).join(','));
  check('free library IPs still appear, on :443, behind the owner', feedAddrs.indexOf('172.64.151.179') > 1 && /172\.64\.151\.179:443\?/.test(feedSub), 'idx=' + feedAddrs.indexOf('172.64.151.179'));
  const noRepo = await (await req3('/sub/' + env3.UUID + '?norepo=1')).text();
  check('?norepo=1 still drops the library IPs', !noRepo.includes('172.64.151.179'));
}
console.log(failures ? ('\n' + failures + ' FAILED\n- ' + failed.join('\n- ')) : '\nALL PASSED');
process.exit(failures ? 1 : 0);
