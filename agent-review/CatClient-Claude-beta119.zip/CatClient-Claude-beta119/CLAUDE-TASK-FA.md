# مأموریت Claude — Cat Client beta119

## Baseline الزامی
- Repository: `mazodimobinhost-creator/cat-client`
- Branch: `arena/c5b36768-cat-client`
- Snapshot: `0490390` یا جدیدتر
- Android: `1.10.0-beta118` / versionCode 185
- Cat Panel: `6.69.0`
- Wizard: `1.3.1`

ابتدا نسخه‌ها و SHA256SUMS را بررسی کن. اگر snapshot قدیمی است patch تولید نکن.

## هدف
سه قابلیت واقعی بساز:
1. target مستقل Cloudflare Pages برای Cat Client؛
2. انتخاب Worker/Pages در Wizard اندروید؛
3. orchestration آزمایشی profileهای موجود ECH/F&F/IPv6/WARP/MASQUE.

## قوانین قطعی
- منبع اصلی Worker فقط `app/src/main/assets/panels/catclient.worker.js` است.
- minified/HTML/release asset را دستی ویرایش نکن؛ از source رسمی rebuild کن.
- Worker اصلی و Pages دو target جدا باشند.
- هیچ کدی از `cmliu/edgetunnel` یا پنل خارجی کپی نکن.
- هیچ نام، UI URL، ProxyIP fallback، converter، fingerprint-evasion یا endpoint پنل خارجی وارد محصول نشود.
- برند محصول فقط Cat Client / Cat Panel باشد.
- GPL و copyright واقعی حفظ شوند؛ attribution کد مشتق‌شده حذف نشود.
- Worker، KV، D1، Secrets، UUID و history موجود حذف/reset نشوند.
- تست گوشی/Cloudflare جعل نشود.
- علت 1101 بدون Live Log قطعی اعلام نشود.
- obfuscation، RC4، control-flow flattening و self-defending ممنوع است.

## 1) baseline audit
بررسی کن:
- Panel=6.69.0؛ Wizard=1.3.1؛ Android beta118.
- دو `catpanel.min.js` از source اصلی ساخته و byte-identical باشند.
- Wizard فقط 404 واقعی را fresh بداند، رمز مستقل UUID بسازد و سه health هم‌نسخه بخواهد.
- compatibility date هر سه deploy path برابر `2026-09-01` و flags خالی باشد.
- تست‌های فعلی را قبل و بعد اجرا کن.
- working tree/provenance را گزارش کن.

## 2) Pages مستقل
ساختار پیشنهادی:
```
pages/catclient/
  src/_worker.js
  public/index.html
  public/panel.js
  public/panel.css
  _routes.json
  wrangler.jsonc
  manifest.json
  README.md
  tests/
dist-pages/catclient-pages.zip
dist-pages/manifest.json
dist-pages/SHA256SUMS.txt
```
شرایط:
- implementation مستقل Cat Client، بدون کپی خارجی.
- `/health` سریع و مستقل از load/decompress UI؛ پاسخ شامل `ok:true`, `panel:"cat-panel"`, `target:"pages"`, نسخه دقیق.
- `/api/version`، پنل، subscription و tunnel routeهای واقعاً سازگار.
- static UI از Function جدا؛ بدون external script/font/style.
- فارسی/انگلیسی/RTL و 44px حفظ شود.
- KV/Secret binding صریح؛ هیچ Secret در source/manifest.
- OPEN_PANEL/OPEN_SUB بدون onboarding امن فعال نشود.
- package deterministic و hashدار؛ قابل deploy با Wrangler رسمی.
- محدودیت Direct Upload + Functions را پنهان نکن.

## 3) Android Worker/Pages selector
تعریف کن:
```kotlin
enum class CloudflareDeployTarget { WORKER, PAGES }
```
در Wizard:
- `[Worker] [Pages — Experimental]`؛ پیش‌فرض Worker؛ فارسی/انگلیسی؛ 44dp؛ accessibility.
- مسیر Worker بدون regression باقی بماند.
- Pages: scope `Pages:Edit`، sanitize نام، fresh-only، بررسی project پیش از write.
- فقط نبودن اثبات‌شده پروژه اجازه نصب بدهد؛ 200/401/403/409/5xx/timeout/network/malformed همگی توقف.
- پروژه موجود update/delete نشود.
- اگر API رسمی قابل اثبات است: create project، manifest/hash، check/upload assets، Function bundle، create deployment، poll، verify.
- موفقیت فقط سه `/health` غیرcache، هم‌نسخه و `target=pages`.
- شکست health هیچ resource را حذف نکند.
- credential در log/URL/state نباشد.
- اگر API رسمی قابل اثبات نیست endpoint خیالی نساز؛ قابلیت واقعی `Export Pages Package + Open Pages Dashboard` بساز، نه دکمه deploy جعلی.

## 4) orchestration آزمایشی اتصال
فقط profileهای واقعاً موجود را بررسی کن:
- baseline، mci-ech، mci-ipv6، mci-ipv6-ff، irancell-ff، WARP، WARP-in-WARP، MASQUE/H2.
- protocol جدید نساز.
- نتیجه‌ها: `SUCCESS`, `FAILED`, `INCONCLUSIVE`, `UNKNOWN`, `NOT_CONFIGURED`, `ORBOT_OFF`.
- snapshot شبکه قبل/بعد؛ HTTP واقعی از همان profile؛ فقط 2xx = SUCCESS.
- network switch/captive = INCONCLUSIVE و بدون history.
- IP/country فقط probe تازه با timestamp؛ cache/حدس ممنوع.
- port-open و panel health موفقیت tunnel نیست.
- dnstt بدون transport evidence = UNKNOWN؛ ORBOT_OFF جدا.
- probe فقط page-visible/network-change/manual با minimum interval.
- feature flag آزمایشی، پیش‌فرض خاموش، قابل توقف و دارای battery/data budget.
- profile فقط پس از SUCCESS قطعی تغییر کند؛ loop/failover بی‌نهایت ممنوع.
- policy deterministic و دلیل نتیجه در UI دیده شود.

## 5) تست‌های اجباری
Worker: syntax/import/health/version/panel/artifact size؛ Wizard 404/200/401/403/409/5xx/network/timeout/malformed/race؛ 3 health؛ mismatch/cache؛ no DELETE/no secret log.

Pages: package structure، deterministic hash، Function import، health target/version، static paths، no external assets/foreign branding/credentials، fresh-only/no overwrite، timeout، malformed API، health failure preserves resources.

Android: Kotlin compile، Worker default، Pages Experimental، selector accessibility/process recreation، no token leak، hash verify، lifecycle cancellation، background stops probe، network switch/captive INCONCLUSIVE، non-2xx FAILED، same-profile 2xx SUCCESS، dnstt/Orbot rules، history/min interval.

UI: RTL/LTR، 44dp/px، mobile overflow، labels، handlers؛ هیچ دکمه برای قابلیت پیاده‌نشده.

## 6) نسخه و وضعیت
فقط پس از تست موفق:
- Android `1.10.0-beta119` و versionCode بعدی؛
- Panel `6.70.0`؛
- Wizard فقط اگر تغییر کرد bump شود.
- هیچ release/commit/push نکن.
- وضعیت‌ها صریح: NOT DEVICE TESTED، NOT TESTED ON REAL MCI/IRANCELL، NOT VERIFIED ON REAL CLOUDFLARE PAGES، 1101 NEEDS LIVE LOG.

## خروجی الزامی
یک ZIP فقط شامل فایل‌های تغییرکرده با مسیر کامل، به‌علاوه:
- `PATCH.diff`
- `CHANGES.md`
- `TEST-RESULTS.md`
- `NOT-TESTED.md`
- `SECURITY-NOTES.md`
- `dist-pages/catclient-pages.zip`
- `dist-pages/manifest.json`
- `dist-pages/SHA256SUMS.txt`

گزارش بخش‌های زیر را داشته باشد:
`IMPLEMENTED`, `VERIFIED`, `FAILED`, `NOT IMPLEMENTED`, `NEEDS DEVICE TEST`, `NEEDS CLOUDFLARE TEST`, `FILES CHANGED`, `COMMANDS ACTUALLY RUN`, `TESTS ACTUALLY RUN`, `TESTS NOT RUN`, `KNOWN RISKS`, `ROLLBACK PLAN`.

هیچ قابلیت ناقص را ready اعلام نکن و هیچ تست اجرا‌نشده را PASS ننویس.
