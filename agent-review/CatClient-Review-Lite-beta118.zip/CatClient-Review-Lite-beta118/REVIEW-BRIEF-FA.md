# بسته ممیزی Cat Client — beta118

## هویت بسته

- Repository: `mazodimobinhost-creator/cat-client`
- Branch: `arena/c5b36768-cat-client`
- Snapshot commit: `5d06f93e36f2c0342a341be98323e6b5f057b358`
- App: `1.10.0-beta118` / versionCode `185`
- Panel: `6.68.0`
- Wizard: `1.3.1`
- وضعیت انتشار: Pre-release / Test Candidate

این ZIP فقط برای ممیزی آفلاین است. هیچ Token، Cookie، UUID واقعی، password، Secret یا داده Cloudflare کاربر داخل آن قرار داده نشده است. رشته `github_pat_ABCDEFGHIJKLMNOPQRSTUVWX` که در تست پنل دیده می‌شود fixture ساختگی و عمومی تست است، نه credential واقعی.

## هدف

پنج ممیز مستقل باید کد واقعی همین بسته را بررسی کنند و فقط یک گزارش متنی evidence-based برگردانند. حوزه‌ها:

1. Android، اتصال‌ها و lifecycle
2. Cloudflare Worker، Wizard و Error 1101
3. UI/UX، طراحی گرافیک، فارسی/RTL و accessibility
4. امنیت، Secretها، bindingها و deploy/update
5. تست‌ها، CI، یکپارچگی و اولویت‌بندی نهایی

## مشکلات و محدودیت‌های شناخته‌شده

- artifact سنگین RC4/control-flow-obfuscated قبلی در گزارش واقعی Cloudflare از ابتدا 1101 داده است.
- beta118 تمام مسیرهای deploy را به Worker عادی minified ESM حدود 540KB تغییر داده است.
- بدون Live Log/stack trace نمی‌توان علت همه 1101ها را قطعی دانست.
- Wizard فقط HTTP 404 واقعی را fresh install می‌داند؛ Worker موجود و پاسخ مبهم را fail-closed متوقف می‌کند.
- update Worker موجود در Wizard عمداً مسدود است تا Secret/KV/D1/R2/IOT_DB/custom bindings جدا نشوند.
- `DATA_PLANE_ENABLED` در نصب تازه پیش‌فرض خاموش است؛ control-plane و `/health` می‌مانند و tunnel باید 403 بدهد.
- نصب تازه فقط پس از سه `/health` سالم و متوالی موفق است.
- UUID/password fallback و subscription-token migration هنوز موضوع قابل بررسی‌اند.
- تست گوشی فیزیکی و deploy واقعی beta118 روی Cloudflare انجام نشده است.

## قوانین ممیزی

- فقط فایل موجود در ZIP را مبنا قرار دهید.
- فایل، کلاس، endpoint، تست، خط یا نتیجه CI خیالی نسازید.
- ابتدا فهرست فایل‌هایی را که واقعاً خوانده‌اید اعلام کنید.
- هر finding باید مسیر فایل، symbol، line range، evidence کوتاه، impact و confidence داشته باشد.
- Severity بدون evidence اعلام نشود.
- کد GPL پروژه دیگر کپی نشود؛ الگو و رفتار را می‌توان مستقل مقایسه کرد.
- روش دورزدن Cloudflare Trust & Safety یا Abuse detection ارائه نشود.
- حذف Worker، KV، D1، UUID، Secret، history یا ساخت Worker تصادفی پیشنهاد نشود.
- port-open، panel health یا TCP connect به‌تنهایی موفقیت tunnel محسوب نشود.
- تست گوشی یا Cloudflare واقعی جعل نشود.
- اگر تست اجرا نشده، صریحاً `TESTS ACTUALLY RUN: NONE` بنویسید.
- خروجی فقط متن باشد؛ PR یا push لازم نیست.

## معیارهای اتصال و probe

- موفقیت Worker/profile فقط با HTTP 2xx واقعی از همان profile قابل اثبات است.
- تغییر شبکه یا captive portal هنگام probe برابر `INCONCLUSIVE` و بدون ثبت history است.
- dnstt بدون evidence حمل‌ونقل `UNKNOWN` است.
- `ORBOT_OFF` و `NOT_CONFIGURED` باید مستقل باشند.
- IP/country فقط از probe تازه همراه timestamp؛ cache قدیمی یا حدس ممنوع.
- probe در app/page بسته ممنوع؛ فقط page-visible، network-change یا manual با minimum interval.

## خروجی مشترک الزامی

```text
AGENT:
ROLE:
SNAPSHOT VERIFIED:
FILES ACTUALLY READ:
COMMANDS ACTUALLY RUN:
TESTS ACTUALLY RUN:
EXISTING GOOD IMPLEMENTATIONS:
CONFIRMED FINDINGS:
FALSE OR UNVERIFIED CLAIMS:
TOP 5 FIXES:
PATCH GUIDANCE:
REGRESSION TESTS:
DEVICE/CLOUDFLARE TESTS NOT RUN:
RISKS:
RELEASE VERDICT:
```

برای هر finding:

```text
ID:
SEVERITY:
FILE:
SYMBOL/LINES:
EVIDENCE:
REPRODUCTION:
IMPACT:
MINIMAL FIX:
TEST:
ROLLBACK:
CONFIDENCE:
```
