package com.cat.client

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.util.zip.ZipFile
import kotlin.coroutines.coroutineContext

enum class ApkVariant(val suffix: String) {
    Universal("universal"),
    ArmeabiV7a("armeabi-v7a"),
    Arm64V8a("arm64-v8a"),
    X86("x86"),
    X86_64("x86_64"),
}

data class ReleaseAsset(val id: Long, val name: String, val url: String, val size: Long)

data class AppRelease(
    val version: String,
    val url: String,
    val apk: ReleaseAsset? = null,
    val checksums: ReleaseAsset? = null,
) {
    val downloadable: Boolean get() = apk != null && checksums != null
}

/** Why an update was refused after download — surfaced verbatim to the UI. */
enum class AppFailureReason { SIGNER, CHECKSUM, PACKAGE, VERSION, VARIANT, GENERIC }

class UpdateRejectedException(val reason: AppFailureReason, message: String) : IOException(message)

data class AppApkMetadata(
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val signerSha256: Set<String>,
    val variant: ApkVariant?,
)

object AppUpdatePolicy {
    /** `1.10.0` and pre-releases like `1.10.0-beta10` (the app ships betas!). */
    private val VERSION_REGEX = Regex("([0-9]+(?:\\.[0-9]+)*)(?:-([A-Za-z]+)([0-9]+))?")

    data class VersionParts(val core: List<Long>, val preName: String, val preNum: Long)

    fun normalizedVersion(version: String): String {
        val value = version.trim().let { if (it.startsWith("v", ignoreCase = true)) it.drop(1) else it }
        if (value.length > 100) return ""
        val m = VERSION_REGEX.matchEntire(value) ?: return ""
        val core = m.groupValues[1]
        if (core.split('.').any { it.toLongOrNull() == null }) return ""
        return if (m.groupValues[2].isEmpty()) core else core + "-" + m.groupValues[2] + m.groupValues[3]
    }

    fun isNewer(latestVersion: String, currentVersion: String): Boolean {
        val latest = parts(latestVersion) ?: return false
        val current = parts(currentVersion) ?: return false
        for (index in 0 until maxOf(latest.core.size, current.core.size)) {
            val comparison = latest.core.getOrElse(index) { 0L }.compareTo(current.core.getOrElse(index) { 0L })
            if (comparison != 0) return comparison > 0
        }
        // Same core numbers: a final release outranks its pre-release; two
        // pre-releases compare by their number (beta10 > beta9 — this is what
        // silently killed in-app updates before).
        val latestFinal = if (latest.preName.isEmpty()) 1 else 0
        val currentFinal = if (current.preName.isEmpty()) 1 else 0
        if (latestFinal != currentFinal) return latestFinal > currentFinal
        if (latest.preName != current.preName) return latest.preName > current.preName
        return latest.preNum > current.preNum
    }

    fun shouldPrompt(latest: String, current: String, skipped: String?): Boolean =
        isNewer(latest, current) &&
            (skipped == null || parts(latest)?.core?.dropLastWhile { it == 0L } != parts(skipped)?.core?.dropLastWhile { it == 0L })

    fun detectVariant(entries: Sequence<String>): ApkVariant? {
        val nativeLibrary = Regex("^lib/([^/]+)/libclash\\.so$")
        val nativeEntries = entries.mapNotNull { nativeLibrary.matchEntire(it)?.groupValues?.get(1) }
            .toList()
        val abis = nativeEntries.toSet()
        if (abis.size != nativeEntries.size) return null
        val variants = ApkVariant.entries.filter { it != ApkVariant.Universal }
        return when {
            abis == variants.map { it.suffix }.toSet() -> ApkVariant.Universal
            abis.size == 1 -> variants.singleOrNull { it.suffix == abis.single() }
            else -> null
        }
    }

    fun variantOfApk(file: File): ApkVariant? = ZipFile(file).use { archive ->
        detectVariant(archive.entries().asSequence().filterNot { it.isDirectory }.map { it.name })
    }

    fun validateApk(candidate: AppApkMetadata, installed: AppApkMetadata, release: AppRelease) {
        if (candidate.packageName != installed.packageName || candidate.packageName.isBlank()) {
            throw UpdateRejectedException(AppFailureReason.PACKAGE, "Update package does not match this app")
        }
        val releaseVersion = normalizedVersion(release.version)
        if (releaseVersion.isEmpty() || normalizedVersion(candidate.versionName) != releaseVersion ||
            !isNewer(release.version, installed.versionName) || candidate.versionCode <= installed.versionCode
        ) {
            throw UpdateRejectedException(AppFailureReason.VERSION, "Update version does not match the newer release")
        }
        if (candidate.signerSha256.isEmpty() || installed.signerSha256.isEmpty()) {
            throw UpdateRejectedException(AppFailureReason.SIGNER, "Update APK signing certificate could not be read")
        }
        if (candidate.signerSha256 != installed.signerSha256) {
            throw UpdateRejectedException(AppFailureReason.SIGNER, "Update signing certificate does not match this app")
        }
        if (candidate.variant == null || candidate.variant != installed.variant) {
            throw UpdateRejectedException(AppFailureReason.VARIANT, "Update APK type does not match this app")
        }
    }

    private fun parts(version: String): VersionParts? {
        val normalized = normalizedVersion(version)
        if (normalized.isEmpty()) return null
        val m = VERSION_REGEX.matchEntire(normalized) ?: return null
        return VersionParts(
            core = m.groupValues[1].split('.').map { it.toLong() },
            preName = m.groupValues[2].lowercase(),
            preNum = m.groupValues[3].toLongOrNull() ?: 0L,
        )
    }
}

object GitHubReleaseClient {
    suspend fun latest(variant: ApkVariant?): AppRelease = withContext(Dispatchers.IO) {
        parseRelease(readText(LATEST_RELEASE_URL, 1_048_576, asset = false), variant)
    }

    /**
     * Download a plain source asset (panel / wizard worker) from the latest
     * GitHub release. Same URL shape the wizard uses, same host allow-list.
     */
    suspend fun releaseAsset(name: String, maxBytes: Int): String {
        if (!name.matches(Regex("[A-Za-z0-9._-]{1,80}"))) {
            throw IOException("GitHub asset name is invalid")
        }
        // github.com -> release-assets.githubusercontent.com is blocked on many
        // Iranian networks, which silently killed the in-app panel update. Walk
        // the same mirror chain the free-config sources use before giving up.
        val direct = "$LATEST_DOWNLOAD_BASE/$name"
        val candidates = buildList {
            add(direct)
            ASSET_MIRRORS.forEach { add(it + direct) }
        }
        var lastError: IOException? = null
        for (candidate in candidates) {
            try {
                return readText(candidate, maxBytes, asset = true)
            } catch (error: IOException) {
                lastError = error
            }
        }
        throw (lastError ?: IOException("GitHub asset download failed"))
    }

    /** A file straight from the repository main branch via jsDelivr — reachable
     * on most Iranian networks and always the freshest committed copy. */
    suspend fun repositoryFile(path: String, maxBytes: Int): String {
        require(path.matches(Regex("[A-Za-z0-9/._-]{1,160}"))) { "Repository path is invalid" }
        return readText("https://cdn.jsdelivr.net/gh/$GITHUB_OWNER/$GITHUB_REPOSITORY@main/$path", maxBytes, asset = true)
    }

    suspend fun expectedSha256(release: AppRelease): String = withContext(Dispatchers.IO) {
        val apk = release.apk ?: throw IOException("Release APK is not uploaded yet")
        val checksums = release.checksums ?: throw IOException("Release checksums are not uploaded yet")
        requireAssetUrl(checksums.url, release.version, "SHA256SUMS")
        requireAssetUrl(apk.url, release.version, apk.name)
        parseChecksum(readText(checksums.url, 65_536, asset = true), apk.name)
    }

    fun parseRelease(json: String, variant: ApkVariant?): AppRelease {
        try {
            val response = JSONObject(json)
            if (response.getBoolean("draft") || response.getBoolean("prerelease")) {
                throw IOException("GitHub release is not a stable release")
            }
            val tag = response.getString("tag_name")
            val version = AppUpdatePolicy.normalizedVersion(tag)
            if (version.isEmpty() || tag != tag.trim()) throw IOException("GitHub release version is invalid")
            val releaseUrl = response.getString("html_url")
            val apkName = variant?.let { "CatClient-V$version-${it.suffix}.apk" }
            val assets = response.getJSONArray("assets")
            val selected = mutableMapOf<String, ReleaseAsset?>()
            for (index in 0 until assets.length()) {
                val asset = assets.getJSONObject(index)
                val name = asset.getString("name")
                if (name != apkName && name != "SHA256SUMS") continue
                if (selected.containsKey(name)) throw IOException("GitHub release contains duplicate assets")
                selected[name] = null
                if (asset.getString("state") != "uploaded") continue
                val id = positiveLong(asset, "id")
                val size = positiveLong(asset, "size")
                val url = asset.getString("browser_download_url")
                selected[name] = ReleaseAsset(id, name, url, size)
            }
            return AppRelease(tag, releaseUrl, selected[apkName], selected["SHA256SUMS"])
                .also { validateRelease(it, variant) }
        } catch (error: JSONException) {
            throw IOException("GitHub release response was invalid", error)
        }
    }

    fun parseChecksum(text: String, assetName: String): String {
        val checksumLine = Regex("^([a-fA-F0-9]{64}) [ *](.+)$")
        val matches = text.lineSequence().filter { it.isNotBlank() }.map { line ->
            checksumLine.matchEntire(line.removeSuffix("\r"))
                ?: throw IOException("Release checksum file is malformed")
        }.filter { it.groupValues[2] == assetName }.map { it.groupValues[1].lowercase() }.toList()
        return matches.singleOrNull() ?: throw IOException("Release checksum is missing or duplicated")
    }

    fun validateRelease(release: AppRelease, variant: ApkVariant?) {
        val version = AppUpdatePolicy.normalizedVersion(release.version)
        if (version.isEmpty() || release.version != release.version.trim()) {
            throw IOException("GitHub release version is invalid")
        }
        requireRepositoryUrl(release.url, "/$GITHUB_OWNER/$GITHUB_REPOSITORY/releases/tag/${release.version}")
        for ((asset, expectedName) in listOf(
            release.apk to variant?.let { "CatClient-V$version-${it.suffix}.apk" },
            release.checksums to "SHA256SUMS",
        )) {
            if (asset == null) continue
            if (asset.id <= 0 || asset.size <= 0 || asset.name != expectedName) {
                throw IOException("GitHub release asset is invalid")
            }
            requireAssetUrl(asset.url, release.version, asset.name)
        }
    }

    internal fun requireAssetUrl(url: String, tag: String, name: String) {
        requireRepositoryUrl(url, "/$GITHUB_OWNER/$GITHUB_REPOSITORY/releases/download/$tag/$name")
    }

    private fun positiveLong(json: JSONObject, key: String): Long {
        val value = json.get(key)
        if (value !is Int && value !is Long) throw IOException("GitHub release asset $key is invalid")
        return (value as Number).toLong().takeIf { it > 0 }
            ?: throw IOException("GitHub release asset $key is invalid")
    }

    private fun requireRepositoryUrl(url: String, path: String) {
        val uri = checkedUri(url)
        if (uri.host != "github.com" || uri.rawPath != path || uri.rawQuery != null) {
            throw IOException("GitHub release URL is invalid")
        }
    }

    private fun checkedUri(url: String): URI {
        val uri = try {
            URI(url)
        } catch (error: Exception) {
            throw IOException("GitHub release URL is invalid", error)
        }
        if (uri.scheme != "https" || uri.userInfo != null || uri.port != -1 || uri.fragment != null || uri.host == null) {
            throw IOException("GitHub release URL is invalid")
        }
        return uri
    }

    private suspend fun readText(initialUrl: String, maxBytes: Int, asset: Boolean): String {
        var url = initialUrl
        repeat(5) {
            coroutineContext.ensureActive()
            val uri = checkedUri(url)
            if (asset) {
                if (uri.host !in ASSET_HOSTS) {
                    throw IOException("GitHub asset redirected to an invalid host")
                }
            } else if (url != LATEST_RELEASE_URL) {
                throw IOException("GitHub API redirected to an invalid URL")
            }
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 5_000
            connection.readTimeout = 5_000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", if (asset) "application/octet-stream" else "application/vnd.github+json")
            connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            connection.setRequestProperty("User-Agent", "Cat Client/${BuildConfig.VERSION_NAME}")
            try {
                val status = connection.responseCode
                if (status in setOf(301, 302, 303, 307, 308)) {
                    val location = connection.getHeaderField("Location") ?: throw IOException("GitHub redirect has no URL")
                    url = uri.resolve(location).toString()
                } else {
                    if (status !in 200..299) throw IOException("GitHub release request failed: $status")
                    if (connection.contentLengthLong > maxBytes) throw IOException("GitHub response is too large")
                    return connection.inputStream.use { input ->
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(8_192)
                        while (true) {
                            coroutineContext.ensureActive()
                            val count = input.read(buffer)
                            if (count == -1) break
                            if (output.size() + count > maxBytes) throw IOException("GitHub response is too large")
                            output.write(buffer, 0, count)
                        }
                        output.toString(Charsets.UTF_8.name())
                    }
                }
            } finally {
                connection.disconnect()
            }
        }
        throw IOException("GitHub release redirected too many times")
    }

    private const val GITHUB_OWNER = "mazodimobinhost-creator"
    private const val GITHUB_REPOSITORY = "cat-client"
    private const val LATEST_RELEASE_URL =
        "https://api.github.com/repos/$GITHUB_OWNER/$GITHUB_REPOSITORY/releases/latest"
    private const val LATEST_DOWNLOAD_BASE =
        "https://github.com/$GITHUB_OWNER/$GITHUB_REPOSITORY/releases/latest/download"

    private val ASSET_HOSTS = setOf(
        "github.com",
        "release-assets.githubusercontent.com",
        "objects.githubusercontent.com",
        "ghproxy.net",
        "gh-proxy.com",
        "cdn.jsdelivr.net",
    )

    private val ASSET_MIRRORS = listOf("https://ghproxy.net/", "https://gh-proxy.com/", "https://ghproxy.link/", "https://mirror.ghproxy.com/")
}
