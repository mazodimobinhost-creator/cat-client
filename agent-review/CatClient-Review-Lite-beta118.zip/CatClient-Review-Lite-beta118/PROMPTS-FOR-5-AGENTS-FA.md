# متن آماده برای پنج ایجنت

ZIP همین پوشه را همراه متن مربوط به هر ایجنت ارسال کنید. فایل `REVIEW-BRIEF-FA.md` نیز باید خوانده شود.

---

## 1) Gemini — Android و اتصال‌ها

```text
فایل CatClient-Agent-Review-beta118.zip را باز کن و ابتدا REVIEW-BRIEF-FA.md را بخوان.
تو ممیز Android/Kotlin و اتصال‌های Cat Client هستی.

فقط فایل‌های واقعی ZIP را بررسی کن، به‌ویژه:
- app/src/main/java/com/cat/client/
- app/src/main/java/com/whitedns/
- app/src/test/
- app/src/androidTest/
- AndroidManifest.xml و build.gradle.kts

بررسی کن:
- lifecycle، coroutine cancellation و thread safety
- network/profile evidence و HTTP probe واقعی
- captive portal و network change mid-probe
- history separation و cap
- IP/country/operator freshness و timestamp
- multi-SIM/roaming بدون حدس
- Orbot و dnstt states
- page visibility و minimum probe interval
- battery/data use
- parser/config/runtime consistency

failover، protocol یا selection logic جدید پیشنهاد نده. تست گوشی را جعل نکن.
خروجی فقط متن و دقیقاً با قالب مشترک REVIEW-BRIEF باشد.
```

---

## 2) ChatGPT — Worker، Wizard و Error 1101

```text
فایل CatClient-Agent-Review-beta118.zip را باز کن و ابتدا REVIEW-BRIEF-FA.md را بخوان.
تو ممیز Cloudflare Worker، Wizard و Error 1101 هستی.

فایل‌های اصلی:
- app/src/main/assets/panels/catclient.worker.js
- app/src/main/assets/panels/catclient.wizard.js
- app/src/main/assets/panels/catpanel.min.js
- scripts/panels/
- wrangler.jsonc
- .github/workflows/deploy-worker.yml

بررسی کن:
- top-level initialization و startup cost
- تمام fetch return paths
- exception، Promise، waitUntil و WebSocket handling
- compatibility date/flags
- تفاوت readable source، minified deploy artifact و release artifact
- سه health متوالی و cache bypass
- 1101، malformed health، timeout و route disable
- تشخیص 404/200/401/403/5xx/network/malformed در Wizard
- عدم upload برای existing/inconclusive Worker
- حفظ UUID/KV/D1/IOT_DB/Secrets/custom bindings
- source selection و خطر بازگشت به artifact قدیمی
- UI-packed سبک: فقط تحلیل طراحی؛ RC4 و control-flow سنگین ممنوع

بدون Live Log علت 1101 را قطعی اعلام نکن. راه دورزدن enforcement ارائه نده.
خروجی فقط متن و با قالب مشترک REVIEW-BRIEF باشد.
```

---

## 3) Grok — Red Team امنیت و deploy

```text
فایل CatClient-Agent-Review-beta118.zip را باز کن و REVIEW-BRIEF-FA.md را بخوان.
به‌عنوان Red Team دفاعی، امنیت Cat Client، Panel، Wizard و deploy را بررسی کن.

تمرکز:
- API token scopes و least privilege
- ذخیره یا log شدن token/password/UUID/cookie
- UUID به‌عنوان password fallback
- subscription token rotation/migration
- backup/restore redaction
- SSRF/XSS/injection
- OPEN_PANEL، OPEN_SUB و DATA_PLANE_ENABLED
- open proxy/abuse risk
- binding preservation و declarative deploy
- app-side update در برابر Wizard update
- PANEL_SOURCE_URL و supply chain
- release signing و GitHub Actions permissions
- عملیات destructive و confirmation

Exploit زنده اجرا نکن. credential درخواست نکن. روش bypass ارائه نده.
برای هر finding evidence دقیق فایل/خط بده و false positiveهای گزارش‌های قبلی را جدا کن.
خروجی فقط متن و با قالب مشترک REVIEW-BRIEF باشد.
```

---

## 4) DeepSeek — تست‌ها، CI و کیفیت مهندسی

```text
فایل CatClient-Agent-Review-beta118.zip را باز کن و REVIEW-BRIEF-FA.md را بخوان.
تو ممیز تست، CI و release engineering هستی.

بررسی کن:
- آیا implementationهای مهم واقعاً test دارند؟
- Android compile/JVM/instrumentation coverage
- Wizard 404/200/401/403/500/network/malformed fixtures
- سه health متوالی و reset شمارنده
- default-off data plane
- missing/secret/custom binding tests
- minified artifact syntax/import/health/version consistency
- release asset واقعاً minified است یا artifact دیگری
- APK ABI/signing/zipalign/checksum/version checks
- CI race، duplicate run و auto-generated commits
- tests tautological، fake endpoint یا flaky timing
- stop-release conditions

ابتدا کل workflowها و تست‌های موجود را بخوان؛ تست موجود را missing اعلام نکن.
هیچ endpoint خیالی برای test پیشنهاد نده.
یک ماتریس requirement → implementation → test → CI step → gap ارائه کن.
خروجی فقط متن و با قالب مشترک REVIEW-BRIEF باشد.
```

---

## 5) Claude — UI/UX، طراحی گرافیک و Reviewer نهایی

```text
فایل CatClient-Agent-Review-beta118.zip را باز کن و REVIEW-BRIEF-FA.md را بخوان.
تو ممیز UI/UX، طراحی گرافیک، accessibility و Reviewer نهایی هستی.

فایل‌های Android UI، resources، strings، panel HTML/CSS/JS تولیدشده در worker و تست‌های DOM/UI را بررسی کن.

تمرکز UI:
- hierarchy، navigation و discoverability
- consistency رنگ، typography، iconography و spacing
- RTL/LTR و متن فارسی/انگلیسی
- mobile layout، overflow، keyboard و safe areas
- حداقل touch target 44px
- contrast و accessibility labels
- loading/error/empty states
- panel onboarding، login، diagnostics و destructive confirmation
- شلوغی پنل و دسته‌بندی قابلیت‌ها
- تفاوت UI واقعی با README؛ تصویر یا قابلیت خیالی پیشنهاد نده
- گرافیک‌هایی که واقعاً از resources موجود قابل ساخت‌اند

سپس معماری و findingهای امنیت/1101 را به‌عنوان Reviewer نقد کن، اما بدون خواندن فایل verdict نده.
پیشنهادها را به Quick wins، Medium و Redesign تقسیم کن.
خروجی فقط متن و با قالب مشترک REVIEW-BRIEF باشد.
```

---

## متن کوتاه همراه ZIP برای همه

```text
این ZIP snapshot واقعی Cat Client beta118 است. لطفاً فقط محتوای داخل ZIP را بررسی کن و یک گزارش متنی evidence-based بده. هیچ فایل یا قابلیت فرضی نساز، credential درخواست نکن، تست اجرا‌نشده را موفق اعلام نکن و طبق نقش اختصاصی و قالب REVIEW-BRIEF-FA.md پاسخ بده.
```
