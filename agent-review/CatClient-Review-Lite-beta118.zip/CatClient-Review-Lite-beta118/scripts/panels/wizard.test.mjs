/**
 * Cat Wizard test harness — fakes the Cloudflare API and checks the whole
 * install flow (token → subdomain → KV → upload → route → health).
 * Usage: node scripts/panels/wizard.test.mjs
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const wizardPath = path.join(here, '../../app/src/main/assets/panels/catclient.wizard.js');
const panelPath = path.join(here, '../../app/src/main/assets/panels/catclient.worker.js');
execFileSync(process.execPath, ['--check', wizardPath], { stdio: 'pipe' });
console.log('✓ wizard syntax check passed');

const mod = await import(wizardPath);
const wizard = mod.default;
const T = mod._testing;
const panelSrc = readFileSync(panelPath, 'utf8');
// Version-proof pins: everything below compares against the real bundled source.
const PANEL_VERSION = (panelSrc.match(/CAT_PANEL_VERSION\s*=\s*'([^']+)'/) || [])[1];
// Simulated normal minified module (release asset / committed snapshot).
// Production panels such as BPB deploy a normal bundled/minified Worker rather
// than a large RC4/control-flow-obfuscated runtime.
const minPanelSrc = "var CAT_PANEL_VERSION = '" + PANEL_VERSION + "';\n" + '/* payload */\n'.repeat(300);

let failures = 0;
function check(name, cond, extra) {
  if (cond) console.log('✓ ' + name);
  else { failures++; console.error('✗ ' + name + (extra ? ' — ' + extra : '')); }
}

/* ---------------- fake Cloudflare + GitHub ---------------- */
const state = {
  subdomain: '',
  kv: [],
  scripts: {},
  routes: {},
  calls: [],
  tokenValid: true,
  kvAllowed: true,
  settingsMode: 'normal',
};
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });

T.__setFetch(async (input, init = {}) => {
  const url = typeof input === 'string' ? input : input.url;
  const method = (init.method || 'GET').toUpperCase();
  state.calls.push(method + ' ' + url);
  const auth = (init.headers && (init.headers.authorization || init.headers.Authorization)) || '';

  if (url.startsWith('https://github.com/') || url.startsWith('https://raw.githubusercontent.com/')) {
    if (url.endsWith('catclient.worker.js')) {
      // first mirror fails to prove the fallback chain works
      if (url.includes('/releases/latest/')) return new Response('nope', { status: 404 });
      return new Response(minPanelSrc, { status: 200 });
    }
    if (url.endsWith('catpanel.min.js')) return new Response(minPanelSrc, { status: 200 });
    if (url.endsWith('catclient.wizard.js')) return new Response(readFileSync(wizardPath, 'utf8'), { status: 200 });
    return new Response('nf', { status: 404 });
  }

  if (url.startsWith('https://api.cloudflare.com/client/v4')) {
    const p = url.slice('https://api.cloudflare.com/client/v4'.length);
    if (auth !== 'Bearer good-token' || !state.tokenValid) return json({ success: false, errors: [{ code: 10000, message: 'Authentication error' }] }, 401);
    if (p === '/user/tokens/verify') return json({ success: true, result: { id: 't1', status: 'active' } });
    if (p.startsWith('/accounts?')) return json({ success: true, result: [{ id: 'acc-1', name: 'Amir Account' }] });
    if (p === '/accounts/acc-1/workers/subdomain' && method === 'GET') {
      return state.subdomain ? json({ success: true, result: { subdomain: state.subdomain } }) : json({ success: false, errors: [{ code: 10007, message: 'not found' }] }, 404);
    }
    if (p === '/accounts/acc-1/workers/subdomain' && method === 'PUT') {
      state.subdomain = JSON.parse(init.body).subdomain;
      return json({ success: true, result: { subdomain: state.subdomain } });
    }
    if (p.startsWith('/accounts/acc-1/storage/kv/namespaces')) {
      if (!state.kvAllowed) return json({ success: false, errors: [{ code: 10000, message: 'Authentication error' }] }, 403);
      if (method === 'GET') return json({ success: true, result: state.kv });
      if (method === 'POST') { const ns = { id: 'kv-' + (state.kv.length + 1), title: JSON.parse(init.body).title }; state.kv.push(ns); return json({ success: true, result: ns }); }
    }
    const scriptMatch = p.match(/^\/accounts\/acc-1\/workers\/scripts\/([a-z0-9-]+)(\/settings|\/subdomain)?$/);
    if (scriptMatch) {
      const name = scriptMatch[1];
      const sub = scriptMatch[2] || '';
      if (sub === '/settings' && method === 'GET') {
        if (state.settingsMode === 'network') throw new TypeError('network down');
        if (state.settingsMode === 'malformed') return json({ success: true, result: {} });
        if (/^(401|403|500)$/.test(state.settingsMode)) return json({ success: false, errors: [{ message: 'settings error' }] }, Number(state.settingsMode));
        const s = state.scripts[name];
        return s ? json({ success: true, result: { bindings: s.bindings } }) : json({ success: false, errors: [{ code: 10007, message: 'script not found' }] }, 404);
      }
      if (sub === '/subdomain' && method === 'POST') { state.routes[name] = JSON.parse(init.body).enabled; return json({ success: true, result: { enabled: true } }); }
      if (sub === '' && method === 'PUT') {
        const form = init.body;
        const meta = JSON.parse(await form.get('metadata').text());
        const script = await form.get('worker.js').text();
        state.scripts[name] = { bindings: meta.bindings, script, meta };
        return json({ success: true, result: { id: name } });
      }
    }
    return json({ success: false, errors: [{ message: 'unhandled ' + method + ' ' + p }] }, 500);
  }

  if (new URL(url).pathname === '/health') {
    const name = new URL(url).hostname.split('.')[0];
    if (!state.scripts[name]) return new Response('nf', { status: 404 });
    const isWizard = state.scripts[name].script.includes('CAT_WIZARD_VERSION');
    return json({ ok: true, version: isWizard ? T.CAT_WIZARD_VERSION : PANEL_VERSION });
  }
  return new Response('unhandled ' + url, { status: 500 });
});

const HOST = 'cat-wizard.demo.workers.dev';
function req(url, { method = 'GET', body, env = {} } = {}) {
  const headers = { Host: HOST, 'cf-connecting-ip': '1.2.3.' + Math.floor(Math.random() * 250) };
  if (body !== undefined) headers['content-type'] = 'application/json';
  return wizard.fetch(new Request('https://' + HOST + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) }), env, { waitUntil() {} });
}
async function installEvents(body, env = {}) {
  const res = await req('/api/install', { method: 'POST', body, env });
  const text = await res.text();
  const events = text.split('\n').filter(Boolean).map((l) => JSON.parse(l));
  return { res, events, done: events.find((e) => e.done) };
}

/* 1. token template URL */
{
  check('token template points at profile/api-tokens', T.TOKEN_TEMPLATE_URL.startsWith('https://dash.cloudflare.com/profile/api-tokens?permissionGroupKeys='));
  const decoded = JSON.parse(decodeURIComponent(new URL(T.TOKEN_TEMPLATE_URL).searchParams.get('permissionGroupKeys')));
  check('template has Workers Scripts edit', decoded.some((p) => p.key === 'workers_scripts' && p.type === 'edit'));
  check('template has Workers KV edit', decoded.some((p) => p.key === 'workers_kv_storage' && p.type === 'edit'));
  check('template has Account Settings read (needed to list accounts)', decoded.some((p) => p.key === 'account_settings' && p.type === 'read'));
  check('template scoped to all accounts + zones', T.TOKEN_TEMPLATE_URL.includes('accountId=*') && T.TOKEN_TEMPLATE_URL.includes('zoneId=all'));
  const r = await req('/token');
  check('/token redirects to the template', r.status === 302 && r.headers.get('location') === T.TOKEN_TEMPLATE_URL);
}

/* 2. page + health */
{
  const r = await req('/');
  const html = await r.text();
  check('/ serves the wizard page', r.status === 200 && html.includes('Cat Wizard') && html.includes('id="installBtn"'));
  check('page embeds the token button with template URL', html.includes('id="tokenBtn"') && html.includes('permissionGroupKeys='));
  check('page is Persian by default with EN toggle', html.includes('lang="fa"') && html.includes('id="langBtn"'));
  check('page has no invite field without WIZARD_PASSWORD', !html.includes('id="invite"'));
  const locked = await (await req('/', { env: { WIZARD_PASSWORD: 'secret' } })).text();
  check('page shows invite field with WIZARD_PASSWORD', locked.includes('id="invite"'));
  new Function(T.clientJs()); // parses
  check('client script parses', true);
  const h = await (await req('/health')).json();
  check('/health reports wizard version', h.ok && h.wizard === 'cat-wizard' && h.version === T.CAT_WIZARD_VERSION);
}

/* 3. verify */
{
  const bad = await (await req('/api/verify', { method: 'POST', body: { token: 'bad' } })).json();
  check('verify rejects a bad token', bad.ok === false && bad.error === 'invalid-token');
  const good = await (await req('/api/verify', { method: 'POST', body: { token: 'good-token' } })).json();
  check('verify accepts the token and lists the account', good.ok === true && good.accounts[0].id === 'acc-1' && good.accounts[0].name === 'Amir Account');
  check('verify reports scopes', good.scopes && good.scopes.workers === true && good.scopes.kv === true);
  const missing = await req('/api/verify', { method: 'POST', body: {} });
  check('verify without token → 400', missing.status === 400);
  const inv = await req('/api/verify', { method: 'POST', body: { token: 'good-token' }, env: { WIZARD_PASSWORD: 'secret' } });
  check('invite code enforced', inv.status === 403);
  const invOk = await req('/api/verify', { method: 'POST', body: { token: 'good-token', invite: 'secret' }, env: { WIZARD_PASSWORD: 'secret' } });
  check('invite code accepted', invOk.status === 200);
}

/* 4. full install (fresh account: no subdomain, no KV, no worker) */
let first;
{
  const { res, events, done } = await installEvents({ token: 'good-token', workerName: 'My Panel!!' });
  check('install streams NDJSON', (res.headers.get('content-type') || '').includes('ndjson') && events.length > 5);
  check('install finishes ok', done && done.result && done.result.ok === true, JSON.stringify(done));
  first = done.result;
  check('worker name slugified', first.workerName === 'my-panel');
  check('subdomain auto-created', /^edge-[a-z0-9]{8}$/.test(state.subdomain) && first.workerUrl === 'https://my-panel.' + state.subdomain + '.workers.dev');
  check('KV namespace created + bound', first.kvBound && state.kv.length === 1 && state.kv[0].title === 'my-panel-catpanel');
  const s = state.scripts['my-panel'];
  check('panel script uploaded with the version marker', s && PANEL_VERSION && s.script.includes("CAT_PANEL_VERSION = '" + PANEL_VERSION + "'"));
  check('branch minified snapshot is preferred over releases/latest', events.some((e) => e.step === 'source' && e.level === 'ok' && e.data && e.data.url.includes('raw.githubusercontent.com') && e.data.url.includes('catpanel.min.js')));
  check('normal minified artifact accepted', !events.some((e) => e.step === 'source' && e.level === 'warn'));
  const bind = Object.fromEntries(s.bindings.map((b) => [b.name, b]));
  check('UUID bound as plain_text', bind.UUID && bind.UUID.type === 'plain_text' && /^[0-9a-f-]{36}$/.test(bind.UUID.text));
  check('CAT_KV bound', bind.CAT_KV && bind.CAT_KV.type === 'kv_namespace' && bind.CAT_KV.namespace_id === 'kv-1');
  check('no PANEL_PASSWORD when none supplied', !bind.PANEL_PASSWORD);
  check('nodejs_compat + compat date set', s.meta.compatibility_flags.includes('nodejs_compat') && s.meta.compatibility_date);
  check('route enabled', state.routes['my-panel'] === true);
  check('online after health probe', first.online === true && first.panelVersion === PANEL_VERSION);
  check('result: password = UUID by default', first.password === first.uuid && first.customPassword === false);
  check('result: panel URL unlocks with ?p=<uuid>', first.panelUrl === first.workerUrl + '/?p=' + first.uuid);
  check('result: sub URL /sub/<uuid>', first.subUrl === first.workerUrl + '/sub/' + first.uuid);
  check('result: deep link for the app', first.deepLink.startsWith('catclient://add-sub?url=') && decodeURIComponent(first.deepLink).includes(first.subUrl));
}

/* 5. existing workers fail closed before KV/upload/route mutation */
{
  const beforeScript = state.scripts['my-panel'];
  const beforeKv = state.kv.length;
  const beforeCalls = state.calls.length;
  const { done } = await installEvents({ token: 'good-token', workerName: 'my-panel', password: 'Hunter2!' });
  const calls = state.calls.slice(beforeCalls);
  check('existing worker update is blocked', done && done.ok === false && /already exists|preserving/i.test(done.msg), JSON.stringify(done));
  check('existing script is untouched', state.scripts['my-panel'] === beforeScript);
  check('existing path creates no KV', state.kv.length === beforeKv && !calls.some((x) => x.startsWith('POST https://api.cloudflare.com/client/v4/accounts/acc-1/storage/kv')));
  check('existing path performs no PUT upload', !calls.some((x) => x.includes('/workers/scripts/my-panel') && x.startsWith('PUT ')));
  check('existing path does not toggle route', !calls.some((x) => x.includes('/workers/scripts/my-panel/subdomain') && x.startsWith('POST ')));
}

/* 5a. HTTP 200 with an empty binding list is still an existing Worker */
{
  state.scripts.emptyexisting = { bindings: [], script: 'existing', meta: {} };
  const beforeCalls = state.calls.length;
  const { done } = await installEvents({ token: 'good-token', workerName: 'emptyexisting' });
  const calls = state.calls.slice(beforeCalls);
  check('existing worker with bindings=[] is blocked', done && done.ok === false && /already exists/i.test(done.msg), JSON.stringify(done));
  check('bindings=[] path performs no PUT', !calls.some((x) => x.includes('/workers/scripts/emptyexisting') && x.startsWith('PUT ')));
}

/* 5b. ambiguous existence checks all fail closed before mutation */
{
  for (const mode of ['401', '403', '500', 'network', 'malformed']) {
    state.settingsMode = mode;
    const name = 'guard-' + mode;
    const beforeKv = state.kv.length;
    const beforeCalls = state.calls.length;
    const { done } = await installEvents({ token: 'good-token', workerName: name });
    const calls = state.calls.slice(beforeCalls);
    check('settings ' + mode + ' is inconclusive', done && done.ok === false && /inconclusive/i.test(done.msg), JSON.stringify(done));
    check('settings ' + mode + ' does not create KV', state.kv.length === beforeKv);
    check('settings ' + mode + ' does not upload', !calls.some((x) => x.includes('/workers/scripts/' + name) && x.startsWith('PUT ')));
    check('settings ' + mode + ' does not toggle route', !calls.some((x) => x.includes('/workers/scripts/' + name + '/subdomain') && x.startsWith('POST ')));
  }
  state.settingsMode = 'normal';
}

/* 6. token without KV scope still installs */
{
  state.kvAllowed = false;
  const { done, events } = await installEvents({ token: 'good-token', workerName: 'nokv' });
  check('install without KV scope succeeds', done.result.ok && done.result.kvBound === false);
  check('KV warning logged', events.some((e) => e.step === 'kv' && e.level === 'warn'));
  const bind = Object.fromEntries(state.scripts.nokv.bindings.map((b) => [b.name, b]));
  check('no KV binding but UUID still set', !bind.CAT_KV && bind.UUID);
  state.kvAllowed = true;
}

/* 7. private wizard copy */
{
  const blocked = await req('/api/install', { method: 'POST', body: { token: 'good-token', kind: 'wizard', workerName: 'my-wizard' }, env: { WIZARD_PASSWORD: 'inv' } });
  check('wizard install blocked without invite when WIZARD_PASSWORD set', blocked.status === 403 && !state.scripts['my-wizard']);
  const { done: done2 } = await installEvents({ token: 'good-token', kind: 'wizard', workerName: 'my-wizard', invite: 'inv' }, { WIZARD_PASSWORD: 'inv' });
  check('wizard self-copy deploys', done2.result && done2.result.kind === 'wizard' && done2.result.workerUrl.startsWith('https://my-wizard.'));
  check('wizard copy is the wizard source', state.scripts['my-wizard'].script.includes('CAT_WIZARD_VERSION'));
  const bind = Object.fromEntries(state.scripts['my-wizard'].bindings.map((b) => [b.name, b]));
  check('wizard copy inherits the invite code', bind.WIZARD_PASSWORD && bind.WIZARD_PASSWORD.text === 'inv');
}

/* 8. bad token surfaces a clean error event */
{
  const { done } = await installEvents({ token: 'bad' });
  check('bad token → done:false with message', done && done.ok === false && /Authentication|rejected/i.test(done.msg), JSON.stringify(done));
  const r = await req('/api/install', { method: 'POST', body: {} });
  check('install without token → 400', r.status === 400);
}

/* 9. the panel itself advertises the wizard permissions */
{
  check('panel deep-links back into Cat Client', panelSrc.includes('catclient://add-sub') && panelSrc.includes('catclient://scan'));
}

/* 10. deploy source is the compact, auditable minified module */
{
  check('source chain targets the minified snapshot / release asset',
    T.PANEL_SOURCES.some((u) => u.includes('dist-panel/catpanel.min.js')) && T.PANEL_SOURCES.some((u) => u.includes('releases/latest/download/catclient.worker.js')));
  check('source chain no longer targets the heavy obfuscated snapshot',
    T.PANEL_SOURCES.every((u) => !u.includes('catpanel.obf.js')));
}

console.log(failures === 0 ? '\nWIZARD TESTS PASSED' : '\n' + failures + ' WIZARD TEST(S) FAILED');
process.exit(failures === 0 ? 0 : 1);
